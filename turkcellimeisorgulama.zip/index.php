<?php 
date_default_timezone_set('Europe/Istanbul');
$actual_link = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
   if($_POST){
       
   }
   
   ?>
<html lang="tr" class=" ">
   <link type="text/css" rel="stylesheet" id="dark-mode-custom-link">
   <link type="text/css" rel="stylesheet" id="dark-mode-general-link">
   <style lang="en" type="text/css" id="dark-mode-custom-style"></style>
   <style lang="en" type="text/css" id="dark-mode-native-style"></style>
   <head>
      <link type="text/css" rel="stylesheet" id="dark-mode-custom-link">
      <link type="text/css" rel="stylesheet" id="dark-mode-general-link">
      <style lang="en" type="text/css" id="dark-mode-custom-style"></style>
      <style lang="en" type="text/css" id="dark-mode-native-style"></style>
      <!-- definitions.common.mobile.head.start -->
      <link rel="dns-prefetch" href="//s.turkcell.com.tr">
      <link rel="dns-prefetch" href="//in.hotjar.com">
      <link rel="dns-prefetch" href="//rest.segmentify.com">
      <link rel="dns-prefetch" href="//script.hotjar.com">
      <link rel="dns-prefetch" href="//static.hotjar.com">
      <link rel="dns-prefetch" href="//vars.hotjar.com">
      <link rel="dns-prefetch" href="//www.facebook.com">
      <link rel="dns-prefetch" href="//www.google.com.tr-gmtdmp">
      <link rel="dns-prefetch" href="//www.googleadservices.com">
      <link rel="dns-prefetch" href="//www.google-analytics.com">
      <link rel="dns-prefetch" href="//www.googletagmanager.com">
      <!-- End definitions.common.mobile.head.start -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="ie=edge; chrome=1">
      <meta name="format-detection" content="telephone=no">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
      <meta name="msapplication-tap-highlight" content="no">
      <script type="text/javascript" async="" src="http://www.google-analytics.com/analytics.js"></script><script type="text/javascript" async="" src="https://static.hotjar.com/c/hotjar-1300727.js?sv=7"></script><script gtm="GTM-MLFT" type="text/javascript" async="" src="https://www.google-analytics.com/gtm/optimize.js?id=GTM-N8MTN2Q"></script><script async="" src="//www.googletagmanager.com/gtm.js?id=GTM-MLFT"></script><script src="https://connect.facebook.net/signals/config/470016443928963?v=2.9.52&amp;r=stable" async=""></script><script async="" src="https://connect.facebook.net/en_US/fbevents.js"></script><script async="" src="https://signals.turkcell.com.tr/base.js"></script><script src="https://connect.facebook.net/signals/config/470016443928963?v=2.9.52&amp;r=stable" async=""></script><script async="" src="https://connect.facebook.net/en_US/fbevents.js"></script><script async="" src="https://signals.turkcell.com.tr/base.js"></script><script type="text/javascript" async="" src="https://static.hotjar.com/c/hotjar-1300727.js?sv=7"></script><script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/js?id=G-RZNMT1ZP8E&amp;l=dataLayer&amp;cx=c"></script><script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/js?id=G-56QCZDB4NE&amp;l=dataLayer&amp;cx=c"></script><script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/js?id=G-32LC2MFZNG&amp;l=dataLayer&amp;cx=c"></script><script gtm="GTM-MLFT" type="text/javascript" async="" src="https://www.google-analytics.com/gtm/optimize.js?id=GTM-N8MTN2Q"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script><script async="" src="//www.googletagmanager.com/gtm.js?id=GTM-MLFT"></script><script type="text/javascript" src="/ruxitagentjs_ICA2Vfhqru_10233220201140653.js" data-dtconfig="app=ae39ede7e8dba6c4|rcdec=1209600000|featureHash=ICA2Vfhqru|vcv=2|rdnt=1|uxrgce=1|bp=3|srmcrv=10|cuc=0opryidt|mel=100000|dpvc=1|md=mdcc4=a#header-mobile-profile ^rb div.m-dashboard ^rb div.m-dashboard__phone|ssv=4|lastModification=1645782384897|dtVersion=10233220201140653|srmcrl=1|tp=500,50,0,1|uxdcw=1500|agentUri=/ruxitagentjs_ICA2Vfhqru_10233220201140653.js|reportUrl=/rb_3f2c3bac-8f12-4c72-8ade-c9ccfa775b54|rid=RID_-887004719|rpid=-460068145|domain=turkcell.com.tr"></script>
      <link rel="shortcut icon" href="https://s.turkcell.com.tr/static_lib/assetsv2/common/images/favicon.ico" type="image/vnd.microsoft.icon">
      <link rel="preload" href="https://s.turkcell.com.tr/static_lib/assetsv2/common/fonts/GreycliffCF-Regular.woff2" as="font" type="font/woff2" crossorigin="">
      <link rel="preload" href="https://s.turkcell.com.tr/static_lib/assetsv2/common/fonts/GreycliffCF-Bold.woff2" as="font" type="font/woff2" crossorigin="">
      <link rel="preload" href="https://s.turkcell.com.tr/static_lib/assetsv2/common/fonts/GreycliffCF-Medium.woff2" as="font" type="font/woff2" crossorigin="">
      <link rel="preload" href="https://s.turkcell.com.tr/static_lib/assetsv2/common/fonts/TurkcellIconFont.woff?1645627466000" as="font" type="font/woff" crossorigin="">
      <link rel="stylesheet" href="https://s.turkcell.com.tr/static_lib/assetsv2/common/styles/vendors.css?1645627466000">
      <link rel="stylesheet" href="https://s.turkcell.com.tr/static_lib/assetsv2/common/styles/vendors/smartbanner.min.css?1645627466000">
      <link rel="stylesheet" href="https://s.turkcell.com.tr/static_lib/assetsv2/mobile/styles/app.mobile.min.css?1645627466000">
      <!-- definitions.common.mobile.head.end -->
      <!-- Used by Google Tag Manager and should be imported to here--> 
      <script> 
         var dataLayer = []; 
      </script> 
      <!-- Google Tag Manager --> 
      <script type="text/javascript">
         setTimeout(function () {
             try {
                 (function (w, d, s, l, i) {
                 w[l] = w[l] || []; w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
                    var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
                    j.async = true; j.src = '//www.googletagmanager.com/gtm.js?id=' + i + dl;
                    f.parentNode.insertBefore(j, f);
                 })(window, document, 'script', 'dataLayer', 'GTM-MLFT');
                }
                catch (e) {
                    console.log(e)
                }
         }, 2000);
      </script> 
      <!-- End Google Tag Manager -->
      <link rel="manifest" href="/insider/manifest.json">
      <!-- End definitions.common.mobile.head.end -->
      <script type="application/javascript" async="" src="//cdn.mookie1.com/containr.js"></script>
      <style id="hypeCookie">.m-cookie {position: relative; float: left; left: auto; bottom: auto; }}</style>
      <script async="" src="https://script.hotjar.com/modules.f9262b22b79803e6feba.js" charset="utf-8"></script>
      <style type="text/css">iframe#_hjRemoteVarsFrame {display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;}</style>
      <meta http-equiv="origin-trial" content="A3v9QjmVUCOO7YqFMKHP/NKbn6kY1G1pa2S1TfeXJZUD/tysMONTy6lV0Jkou3rrCjSKRGbqTrgTaZkm1XJ7pQUAAACKeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ21hbmFnZXIuY29tOjQ0MyIsImZlYXR1cmUiOiJDb252ZXJzaW9uTWVhc3VyZW1lbnQiLCJleHBpcnkiOjE2NDMxNTUxOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9">
      <script type="application/javascript" async="" src="//cdn.mookie1.com/containr.js"></script>
      <meta http-equiv="origin-trial" content="A3v9QjmVUCOO7YqFMKHP/NKbn6kY1G1pa2S1TfeXJZUD/tysMONTy6lV0Jkou3rrCjSKRGbqTrgTaZkm1XJ7pQUAAACKeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ21hbmFnZXIuY29tOjQ0MyIsImZlYXR1cmUiOiJDb252ZXJzaW9uTWVhc3VyZW1lbnQiLCJleHBpcnkiOjE2NDMxNTUxOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9">
      <script async="" src="https://script.hotjar.com/modules.f9262b22b79803e6feba.js" charset="utf-8"></script>
      <style type="text/css">iframe#_hjRemoteVarsFrame {display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;}</style>
      <meta http-equiv="origin-trial" content="A3v9QjmVUCOO7YqFMKHP/NKbn6kY1G1pa2S1TfeXJZUD/tysMONTy6lV0Jkou3rrCjSKRGbqTrgTaZkm1XJ7pQUAAACKeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ21hbmFnZXIuY29tOjQ0MyIsImZlYXR1cmUiOiJDb252ZXJzaW9uTWVhc3VyZW1lbnQiLCJleHBpcnkiOjE2NDMxNTUxOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9">
      <meta http-equiv="origin-trial" content="A3v9QjmVUCOO7YqFMKHP/NKbn6kY1G1pa2S1TfeXJZUD/tysMONTy6lV0Jkou3rrCjSKRGbqTrgTaZkm1XJ7pQUAAACKeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ21hbmFnZXIuY29tOjQ0MyIsImZlYXR1cmUiOiJDb252ZXJzaW9uTWVhc3VyZW1lbnQiLCJleHBpcnkiOjE2NDMxNTUxOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9">
   </head>
   <body>
      <script src="https://s.turkcell.com.tr/static_lib/assetsv2/common/scripts/vendors/jquery.min.js?1645627466000"></script>
      <div class="header-bandaid"></div>
      <header class="o-header-mobile o-header-mobile--not-bottom o-header-mobile--pinned o-header-mobile--top">
         <div class="container">
            <div class="o-header-mobile__bar">
               <div class="o-header-mobile__logo">
                  <a class="m-logo" title="Turkcell">
                  <img src="https://s.turkcell.com.tr/static_lib/assetsv2/common/images/content/turkcell-logo.png?1645627466000" alt="Turkcell">
                  </a>
               </div>
               <div class="o-header-mobile__right">
                  <div class="o-header-mobile__buttons">
                     <div class="m-btn-group">
                        <a class="a-btn-icon js-search m-r-0" title="Arama" aria-label="Arama" role="button">
                        <i class="icon-search"></i>
                        </a>
                        <div class="a-user-basket">
                           <a class="a-btn-icon" title="Sepetim" aria-label="Sepetim" role="button">
                           <i class="icon-cart-notification"></i>
                           </a>
                        </div>
                        <a class="a-btn-icon js-login" title="İşlem Merkezi" aria-label="İşlem Merkezi" role="button">
                        <i class="icon-account-regular"></i>
                        </a>
                        <a class="a-btn-icon js-mobile-nav" title="Menu" role="button" aria-label="Menü">
                        <i class="icon-mobile-menu"></i>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="m-header-dropdown">
            <svg width="0" height="0">
               <defs>
                  <clipPath id="m-header-dropdown__clip-path" clipPathUnits="objectBoundingBox">
                     <path d="M0,0 L0,0.9296875 Q0.5,1.0703125 1,0.9296875 L1,0 Z" stroke-width="0"></path>
                  </clipPath>
                  <clipPath id="m-header-dropdown__clip-path--mobile" clipPathUnits="objectBoundingBox">
                     <path d="M0,0 L0,0.9835051546391752 Q0.5,1.0164948453608247 1,0.9835051546391752 L1,0 Z" stroke-width="0"></path>
                  </clipPath>
               </defs>
            </svg>
            <div class="container">
               <div class="o-header-mobile__login-container js-o-header-mobile-login">
                  <div class="m-login">
                     <input type="hidden" id="redirectUrlAfterLogin" value="/tr/turkcellli-olmak/numara-secimi">
                     <h3 data-title="Giriş">Giriş</h3>
                     <div class="m-login__container">
                        <div class="m-grid">
                           <div class="m-grid-col-10 m-grid-offset-right-2">
                              <div class="m-login__main">
                                 <p>Aşağıdaki giriş yöntemlerinden biriyle giriş yapabilirsiniz.</p>
                                 <p class="js-login-error color_punch m-t-10"></p>
                                 <div class="m-login__nonpass">
                                    <p>53977151** numaralı hat üzerinden internete bağlısınız. Numaranızın son 2 hanesini tuşlayarak şifresiz giriş yapabilirsiniz.</p>
                                    <form method="POST" action="/giris/lastTwoDigit" class="m-form" data-parsley-validate="data-parsley-validate" data-parsley-excluded="disabled, :hidden" novalidate="">
                                       <div class="m-form-group ">
                                          <div class="m-form-group__child">
                                             <div class="a-last-numbers" data-numbers="53977151" id="last-number-field">
                                                <div class="a-last-numbers__wrap">
                                                   <div>0539 771 51</div>
                                                   <input name="msisdn" type="tel" required="true" id="last-number-id" placeholder="__" minlength="2" maxlength="2" data-parsley-length-message="Bu alanın uzunluğu min. 2 karakter olmalı." data-parsley-errors-container="#last-number-field" data-parsley-class-handler="#last-number-field">
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="m-form-group ">
                                          <div class="m-form-group__child">
                                             <button class="a-btn a-btn--full js-non-pass-btn" title="Şifresiz Giriş Yap">
                                             Şifresiz Giriş Yap
                                             </button>
                                             <span>veya</span>
                                          </div>
                                       </div>
                                    </form>
                                 </div>
                                 <div class="m-form-group  m-login__fast-login">
                                    <div class="m-form-group__child">
                                       <a class="a-btn a-btn--full a-btn--white js-fast-login-btn a-btn--fast-login" href="javascript:;" title="Hızlı Giriş">
                                       </a>
                                    </div>
                                 </div>
                                 <div class="o-p-header__dropdown__login__continue-anon">
                                    <div class="m-form-group  m-login__footer__go-ahead">
                                       <div class="m-form-group__child">
                                          <span>veya</span>
                                          <a class="a-btn a-btn--full a-btn--secondary a-btn--big a-btn--secondary--white" id="none-login-sale-button" href="javascript:;" title="Giriş yapmadan devam et">
                                          Giriş yapmadan devam et
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="m-login__form">
                                 <div class="m-login__footer">
                                    <div class="m-login__footer__password-forget">
                                       <div class="m-flex">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div id="header-mobile-search" class="o-header-mobile__search js-o-header-mobile-search ">
                  <div class="o-header-mobile__search-area">
                     <h2 class="text-center" data-hj-suppress="">Hoş Geldiniz</h2>
                     <div class="m-search">
                        <form method="GET" action="/arama" class="m-form" data-parsley-validate="data-parsley-validate" data-parsley-excluded="disabled, :hidden" novalidate="">
                           <div class="m-search__input">
                              <button class="a-btn-icon m-search__search" title="">
                              <i class="icon-search"></i>
                              </button>
                              <input type="text" placeholder="Size nasıl yardımcı olabiliriz?" name="qx" autocomplete="off" aria-label="Arama yap" value="">
                              <a class="a-btn-icon m-search__cancel" href="javascript:;" title="">
                              <i class="icon-close"></i>
                              </a>
                           </div>
                           <span class="m-search__powered">Powered by Yaani</span>
                        </form>
                        <script class="m-search__result-template" type="text/x-handlebars-template">
                           <div{{#if recommended}} class="m-search__recommended"{{/if}}>
                           			{{#if lvl1Category}}
                             			<span>{{lvl1Category}}{{#if lvl2Category}} - {{lvl2Category}}{{/if}} {{#if lvl3Category}} - {{lvl3Category}}{{/if}} {{#if lvl4Category}} - {{lvl4Category}}{{/if}}</span>
                           			{{/if}}
                           		{{#if title}}
                            				<p>{{title}}</p>
                           			{{/if}}
                           			{{#if recommended}}
                             			<mark>Önerilen sonuç</mark>
                           		 {{/if}}
                           </div>
                        </script>
                        <script class="m-search__all-result-template" type="text/x-handlebars-template">
                           <li>
                           			<a href="/arama?place=autocomplete&qx={{query}}"><div class="m-search__results">Tüm Sonuçlar</div></a>
                           </li>
                        </script>
                     </div>
                  </div>
                  <div class="o-header-mobile__tags">
                     <div id="" class="m-slider m-slider--tag">
                        <div class="m-slider__swiper swiper-container swiper-container-initialized swiper-container-horizontal swiper-container-ios">
                           <div class="swiper-wrapper">
                              <div class="swiper-slide swiper-lazy swiper-slide-active" style="margin-right: 16px;">
                                 <a class="a-btn a-btn--tag a-btn--tag--true" href="/yukle/tl-yukle?place=qa" title="TL Yükle">
                                 TL Yükle
                                 </a>
                              </div>
                              <div class="swiper-slide swiper-lazy swiper-slide-next" style="margin-right: 16px;">
                                 <a class="a-btn a-btn--tag a-btn--tag--true" href="/yardim/hattiniz/faturali/otomatik-odeme-talimati-nasil-verebilirim" title="
                                    Otomatik Ödeme Talimatı">
                                 Otomatik Ödeme Talimatı
                                 </a>
                              </div>
                           </div>
                           <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                        </div>
                     </div>
                  </div>
                  <div id="gomore-recommendedOffers-section" class="o-header-mobile__popular">
                     <h6 class="text-center">Şu anda popüler</h6>
                     <div id="" class="m-slider">
                        <div class="m-slider__swiper swiper-container swiper-container-initialized swiper-container-horizontal swiper-container-ios">
                           <div class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(68.5px, 0px, 0px);">
                              <div class="swiper-slide swiper-lazy swiper-slide-active" style="margin-right: 16px;">
                                 <a href="/pasaj/cep-telefonu/ios-telefonlar/iphone-12-64-gb?source=CMS" class="google-analytics-device device-detail-btn m-p-pc  m-p-pc--short" style="" data-product-id="iphone-12-64-gb" data-campaign="campaign,discount," data-href="/pasaj/cep-telefonu/ios-telefonlar/iphone-12-64-gb" data-image-url="https://s.turkcell.com.tr/SiteAssets/Cihaz/cep-telefonu/apple/12/cg/10a.png">
                                    <span class="a-p-card-ribbon a-p-card-ribbon--a a-p-card-ribbon--blue a-p-card-ribbon--red">
                                    1.106 TL İndirim
                                    </span>
                                    <div class="a-fav-button" data-url="/pasaj/user-favorite-operation" data-device-path="/pasaj/cep-telefonu/ios-telefonlar/iphone-12-64-gb" data-device-id="1030988" data-pm-name="iPhone 12 64 GB" style="display: none;">
                                       <span class="tooltip tooltipstered" data-alternative="Favoriden Çıkar">
                                          <svg class="heart" xmlns="http://www.w3.org/2000/svg" width="36" height="32" viewBox="0 0 36 32">
                                             <path fill="#FFC900" fill-rule="nonzero" stroke="#FFC900" class="heart-line" d="M3.058 2.738l-.104.104C-.983 6.779-.985 13.165 2.95 17.1l12.678 12.678c.847.847 2.213.849 3.062 0L31.368 17.1c3.938-3.938 3.938-10.317-.004-14.258l-.104-.104c-3.654-3.654-9.578-3.65-13.237.009l-.614.614c-.137.137-.363.137-.5 0l-.614-.614C12.638-.91 6.709-.913 3.058 2.738zM15.89 4.38c.7.7 1.836.7 2.536 0l.614-.614c3.097-3.097 8.11-3.1 11.201-.009l.104.104c3.379 3.38 3.38 8.846.004 12.221L17.671 28.76c-.285.285-.74.285-1.024 0L3.968 16.08C.596 12.71.598 7.235 3.972 3.86l.104-.104c3.088-3.088 8.106-3.085 11.2.009l.615.614z" transform="translate(-1254 -352) translate(1255 353)"></path>
                                             <path fill="#ffc900" class="heart-fill" d="M15.994 3.47C12.784.213 7.577.215 4.368 3.47l-.258.262C.48 7.412.48 13.379 4.107 17.056l12.445 12.619c.556.563 1.462.558 2.013 0L31.01 17.056c3.628-3.679 3.629-9.642-.002-13.324l-.26-.263c-3.21-3.255-8.413-3.256-11.625 0l-1.057 1.073c-.28.284-.736.282-1.014 0l-1.058-1.073z" transform="translate(-1254 -352) translate(1239 328) translate(16 25)"></path>
                                          </svg>
                                       </span>
                                    </div>
                                    <div class="m-p-pc__body">
                                       <div class="m-p-pc__carousel">
                                          <figure class="m-p-pc__img">
                                             <img src="https://s.turkcell.com.tr/SiteAssets/Cihaz/cep-telefonu/apple/12/cg/10a/10a_94x71.png" data-src="https://s.turkcell.com.tr/SiteAssets/Cihaz/cep-telefonu/apple/12/cg/10a/10a_94x71.png" alt="" class=" ls-is-cached lazyloaded">
                                          </figure>
                                       </div>
                                       <span class="m-p-pc__title">iPhone 12 64 GB</span>
                                    </div>
                                    <div class="m-p-pc__foot">
                                       <div class="m-p-pc__price m-p-pc__price--primary">
                                          5.391,93
                                          <span class="m-p-pc__price__cur">TL x 3AY</span>
                                       </div>
                                       <div class="m-p-pc__price m-p-pc__price--secondary">
                                          <div class="m-p-pc__price m-p-pc__price--dark">13.893
                                             <span class="m-p-pc__price__cur">TL</span>
                                          </div>
                                          <div class="m-p-pc__price m-p-pc__price--old">14.999
                                             <span class="m-p-pc__price__cur">TL
                                             <span class="m-p-pc__price__cur__discount">1.106 TL İndirim</span>
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- google-analytics -->
                                    <div id="google-analytics-device-informations" style="display: none;" data-section-title="Cep Telefonu-Aksesuar" data-product-id="1030988" data-product-name="iPhone 12 64 GB" data-product-price="13893.0" data-product-brand="Apple" data-position="1" data-dimension21="TRY" data-dimension22="true" data-dimension25="Kontratli" data-dimension27="true" data-dimension30="Non-Turkcell" data-dimension156="true" data-dimension157="7.4" data-dimension167="86" data-dimension168="10" data-dimension169="39" data-dimension170="4.91" data-product-category="Cep Telefonu-Aksesuar" data-dimension173="Apple Telefonlar">
                                    </div>
                                    <!-- google-analytics -->
                                 </a>
                              </div>
                              <div class="swiper-slide swiper-lazy swiper-slide-next" style="margin-right: 16px;">
                                 <a href="/pasaj/elektrikli-ev-aletleri/elektrikli-mutfak-aletleri/kahve-makinesi/arzum-ok004-okka-minio-turk-kahvesi-makinesi?source=CMS" class="google-analytics-device device-detail-btn m-p-pc  m-p-pc--short" style="" data-product-id="arzum-ok004-okka-minio-turk-kahvesi-makinesi" data-campaign="campaign,discount," data-href="/pasaj/elektrikli-ev-aletleri/elektrikli-mutfak-aletleri/kahve-makinesi/arzum-ok004-okka-minio-turk-kahvesi-makinesi" data-image-url="https://s.turkcell.com.tr/SiteAssets/Cihaz/aksesuar/arzum/ok004-okka-minio-turk-kahvesi-makinesi/cg/1.png">
                                    <span class="a-p-card-ribbon a-p-card-ribbon--a a-p-card-ribbon--blue a-p-card-ribbon--red">
                                    125 TL İndirim
                                    </span>
                                    <div class="a-fav-button" data-url="/pasaj/user-favorite-operation" data-device-path="/pasaj/elektrikli-ev-aletleri/elektrikli-mutfak-aletleri/kahve-makinesi/arzum-ok004-okka-minio-turk-kahvesi-makinesi" data-device-id="1028193" data-pm-name="Arzum OK004 Okka Minio Türk Kahvesi Makinesi" style="display: none;">
                                       <span class="tooltip tooltipstered" data-alternative="Favoriden Çıkar">
                                          <svg class="heart" xmlns="http://www.w3.org/2000/svg" width="36" height="32" viewBox="0 0 36 32">
                                             <path fill="#FFC900" fill-rule="nonzero" stroke="#FFC900" class="heart-line" d="M3.058 2.738l-.104.104C-.983 6.779-.985 13.165 2.95 17.1l12.678 12.678c.847.847 2.213.849 3.062 0L31.368 17.1c3.938-3.938 3.938-10.317-.004-14.258l-.104-.104c-3.654-3.654-9.578-3.65-13.237.009l-.614.614c-.137.137-.363.137-.5 0l-.614-.614C12.638-.91 6.709-.913 3.058 2.738zM15.89 4.38c.7.7 1.836.7 2.536 0l.614-.614c3.097-3.097 8.11-3.1 11.201-.009l.104.104c3.379 3.38 3.38 8.846.004 12.221L17.671 28.76c-.285.285-.74.285-1.024 0L3.968 16.08C.596 12.71.598 7.235 3.972 3.86l.104-.104c3.088-3.088 8.106-3.085 11.2.009l.615.614z" transform="translate(-1254 -352) translate(1255 353)"></path>
                                             <path fill="#ffc900" class="heart-fill" d="M15.994 3.47C12.784.213 7.577.215 4.368 3.47l-.258.262C.48 7.412.48 13.379 4.107 17.056l12.445 12.619c.556.563 1.462.558 2.013 0L31.01 17.056c3.628-3.679 3.629-9.642-.002-13.324l-.26-.263c-3.21-3.255-8.413-3.256-11.625 0l-1.057 1.073c-.28.284-.736.282-1.014 0l-1.058-1.073z" transform="translate(-1254 -352) translate(1239 328) translate(16 25)"></path>
                                          </svg>
                                       </span>
                                    </div>
                                    <div class="m-p-pc__body">
                                       <div class="m-p-pc__carousel">
                                          <figure class="m-p-pc__img">
                                             <img src="https://s.turkcell.com.tr/SiteAssets/Cihaz/aksesuar/arzum/ok004-okka-minio-turk-kahvesi-makinesi/cg/1/1_94x71.png" data-src="https://s.turkcell.com.tr/SiteAssets/Cihaz/aksesuar/arzum/ok004-okka-minio-turk-kahvesi-makinesi/cg/1/1_94x71.png" alt="" class=" ls-is-cached lazyloaded">
                                          </figure>
                                       </div>
                                       <span class="m-p-pc__title">Arzum OK004 Okka Minio Türk Kahvesi Makinesi</span>
                                    </div>
                                    <div class="m-p-pc__foot">
                                       <div class="m-p-pc__price m-p-pc__price--primary">
                                          36,42
                                          <span class="m-p-pc__price__cur">TL x 36AY</span>
                                       </div>
                                       <div class="m-p-pc__price m-p-pc__price--secondary">
                                          <div class="m-p-pc__price m-p-pc__price--dark">474
                                             <span class="m-p-pc__price__cur">TL</span>
                                          </div>
                                          <div class="m-p-pc__price m-p-pc__price--old">599
                                             <span class="m-p-pc__price__cur">TL
                                             <span class="m-p-pc__price__cur__discount">125 TL İndirim</span>
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- google-analytics -->
                                    <div id="google-analytics-device-informations" style="display: none;" data-section-title="Elektrikli Ev Aletleri" data-product-id="1028193" data-product-name="Arzum OK004 Okka Minio Türk Kahvesi Makinesi" data-product-price="474.0" data-product-brand="Arzum" data-position="1" data-dimension21="TRY" data-dimension22="true" data-dimension25="Kontratli" data-dimension27="true" data-dimension30="Non-Turkcell" data-dimension156="true" data-dimension157="20.9" data-dimension167="104" data-dimension168="4" data-dimension169="10" data-dimension170="4.97" data-product-category="Elektrikli Ev Aletleri" data-dimension173="Elektrikli Mutfak Aletleri" data-dimension174="Kahve Makineleri">
                                    </div>
                                    <!-- google-analytics -->
                                 </a>
                              </div>
                              <div class="swiper-slide swiper-lazy" style="margin-right: 16px;">
                                 <a class="m-card m-card--package m-card--short" href="/paket-ve-tarifeler/yeni-musteri-paketleri/turbo-firsat-avantaj-plus?source=CMS" data-component="">
                                    <div class="m-card__head__short-hat" style="background: #009ed8 radial-gradient(circle at -2.5rem 0,#00b3e3 40%,rgba(0,179,227,.75) 40%,rgba(0,179,227,.75) 60%,rgba(0,179,227,.5) 60%,rgba(0,179,227,.5) 85%,rgba(0,0,0,0) 85%);
                                       color: #fff;"></div>
                                    <div class="m-card__head" style="background: #009ed8 radial-gradient(circle at -2.5rem 0,#00b3e3 40%,rgba(0,179,227,.75) 40%,rgba(0,179,227,.75) 60%,rgba(0,179,227,.5) 60%,rgba(0,179,227,.5) 85%,rgba(0,0,0,0) 85%);
                                       color: #fff;">
                                       <h3 class="m-card__title">Turbo Fırsat Avantaj+</h3>
                                    </div>
                                    <div class="m-card__body">
                                       <div class="m-card__packages">
                                       </div>
                                       <div class="m-card__tariffs">
                                          <div class="a-tariff">
                                             <i class="a-icon icon-cellular"></i>
                                             <div class="a-tariff__data">5<sup>GB</sup></div>
                                             <div class="a-tariff__name">İNTERNET</div>
                                          </div>
                                          <div class="a-tariff">
                                             <i class="a-icon icon-telephone"></i>
                                             <div class="a-tariff__data">500<sup>DK</sup></div>
                                             <div class="a-tariff__name">HER YÖNE</div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="m-card__foot">
                                       <div class="m-flex">
                                          <span class="a-price  a-price--gray">
                                          <span class="a-price-val">66</span>
                                          <sup>
                                          <span class="a-price__currency">TL/AY</span>
                                          </sup>
                                          </span>
                                       </div>
                                    </div>
                                 </a>
                              </div>
                           </div>
                           <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="a-lottie-animation a-lottie-animation--loading" data-animation="Loading">
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1230 1230" width="1230" height="1230" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                  <defs>
                     <clipPath id="__lottie_element_2">
                        <rect width="1230" height="1230" x="0" y="0"></rect>
                     </clipPath>
                  </defs>
                  <g clip-path="url(#__lottie_element_2)">
                     <g style="display: none;">
                        <g>
                           <path></path>
                        </g>
                     </g>
                     <g transform="matrix(0,0,0,0,620.510009765625,617.448974609375)" opacity="0.66" style="display: block;">
                        <g opacity="1" transform="matrix(2,0,0,2,0,0)">
                           <path fill="rgb(26,94,167)" fill-opacity="0.88" d=" M0,-494 C272.63861083984375,-494 494,-272.63861083984375 494,0 C494,272.63861083984375 272.63861083984375,494 0,494 C-272.63861083984375,494 -494,272.63861083984375 -494,0 C-494,-272.63861083984375 -272.63861083984375,-494 0,-494z"></path>
                        </g>
                     </g>
                     <g transform="matrix(0,0,0,0,620.510009765625,617.448974609375)" opacity="1" style="display: block;">
                        <g opacity="1" transform="matrix(2,0,0,2,0,0)">
                           <path fill="rgb(22,109,177)" fill-opacity="0.58" d=" M0,-333 C183.78269958496094,-333 333,-183.78269958496094 333,0 C333,183.78269958496094 183.78269958496094,333 0,333 C-183.78269958496094,333 -333,183.78269958496094 -333,0 C-333,-183.78269958496094 -183.78269958496094,-333 0,-333z"></path>
                        </g>
                     </g>
                     <g style="display: none;">
                        <g>
                           <path></path>
                        </g>
                     </g>
                     <g style="display: none;">
                        <g>
                           <path></path>
                        </g>
                     </g>
                     <g transform="matrix(0,0,0,0,620.510009765625,617.448974609375)" opacity="1" style="display: block;">
                        <g opacity="1" transform="matrix(2,0,0,2,0,0)">
                           <path fill="rgb(40,54,135)" fill-opacity="0.31" d=" M0,-113 C62.36470031738281,-113 113,-62.36470031738281 113,0 C113,62.36470031738281 62.36470031738281,113 0,113 C-62.36470031738281,113 -113,62.36470031738281 -113,0 C-113,-62.36470031738281 -62.36470031738281,-113 0,-113z"></path>
                        </g>
                     </g>
                     <g transform="matrix(0,0,0,0,620.510009765625,617.448974609375)" opacity="1" style="display: block;">
                        <g opacity="1" transform="matrix(2,0,0,2,0,0)">
                           <path fill="rgb(255,200,0)" fill-opacity="1" d=" M43.0099983215332,-61.189998626708984 C35.119998931884766,-66.70999908447266 26.079999923706055,-70.6500015258789 15.9399995803833,-72.98999786376953 C-0.6899999976158142,-76.83999633789062 -16.8700008392334,-75.0999984741211 -32.459999084472656,-68.22000122070312 C-41.08000183105469,-64.41000366210938 -48.709999084472656,-59.16999816894531 -55.27000045776367,-52.4900016784668 C-63.470001220703125,-44.15999984741211 -69.4000015258789,-34.709999084472656 -73.01000213623047,-24.170000076293945 C-73.2300033569336,-23.510000228881836 -73.33999633789062,-23.139999389648438 -73.45999908447266,-22.760000228881836 C-77.16000366210938,-10.569999694824219 -73.69999694824219,-3.8399999141693115 -68.26000213623047,-9.479999542236328 C-68.05000305175781,-9.720000267028809 -67.83000183105469,-9.960000038146973 -67.61000061035156,-10.199999809265137 C-61,-18.389999389648438 -50.869998931884766,-24.969999313354492 -50.869998931884766,-24.969999313354492 C-48.290000915527344,-26.739999771118164 -45.61000061035156,-28.389999389648438 -42.81999969482422,-29.93000030517578 C-39.63999938964844,-31.770000457763672 -36.310001373291016,-33.459999084472656 -33.20000076293945,-34.599998474121094 C-33.20000076293945,-34.599998474121094 -30.31999969482422,-35.900001525878906 -29.549999237060547,-39.86000061035156 C-28.959999084472656,-43.4900016784668 -25.3799991607666,-52.560001373291016 -15.25,-53.150001525878906 C-12.079999923706055,-53.58000183105469 -8.930000305175781,-53.02000045776367 -6.150000095367432,-51.720001220703125 C-1.2599999904632568,-49.43000030517578 2.4800000190734863,-44.84000015258789 3.240000009536743,-39.310001373291016 C3.8499999046325684,-34.91999816894531 2.7799999713897705,-30.770000457763672 0.5099999904632568,-27.489999771118164 C0.3799999952316284,-27.309999465942383 0.23999999463558197,-27.1200008392334 0.09000000357627869,-26.93000030517578 C-1.9500000476837158,-24.329999923706055 -4.550000190734863,-22.450000762939453 -7.659999847412109,-21.389999389648438 C-9.520000457763672,-20.709999084472656 -11.40999984741211,-20.3700008392334 -13.220000267028809,-20.31999969482422 C-14.369999885559082,-20.170000076293945 -15.630000114440918,-20.31999969482422 -16.889999389648438,-20.6200008392334 C-18.31999969482422,-20.90999984741211 -19.6299991607666,-21.3799991607666 -20.760000228881836,-22.010000228881836 C-22.709999084472656,-22.90999984741211 -24.299999237060547,-23.93000030517578 -24.889999389648438,-24.459999084472656 C-25.350000381469727,-24.8799991607666 -25.850000381469727,-25.110000610351562 -26.329999923706055,-25.229999542236328 C-27.399999618530273,-25.399999618530273 -28.270000457763672,-25.200000762939453 -28.90999984741211,-24.93000030517578 C-29.280000686645508,-24.770000457763672 -29.559999465942383,-24.59000015258789 -29.760000228881836,-24.450000762939453 C-32.18000030517578,-22.450000762939453 -34.4900016784668,-20.360000610351562 -36.68000030517578,-18.170000076293945 C-42.41999816894531,-12.210000038146973 -47.2400016784668,-5.449999809265137 -49.5099983215332,-2.109999895095825 C-50.709999084472656,-0.20999999344348907 -51.849998474121094,1.7200000286102295 -52.91999816894531,3.7200000286102295 C-53.90999984741211,5.570000171661377 -54.84000015258789,7.440000057220459 -55.70000076293945,9.319999694824219 C-57.040000915527344,12.3100004196167 -58.310001373291016,15.520000457763672 -59.439998626708984,18.969999313354492 C-59.4900016784668,19.1299991607666 -59.54999923706055,19.290000915527344 -59.599998474121094,19.440000534057617 C-59.66999816894531,19.65999984741211 -59.7400016784668,19.8799991607666 -59.79999923706055,20.100000381469727 C-59.869998931884766,20.31999969482422 -59.93000030517578,20.530000686645508 -60,20.75 C-66.97000122070312,44.29999923706055 -54.41999816894531,57.88999938964844 -43.90999984741211,43.689998626708984 C-43.33000183105469,42.790000915527344 -42.75,41.900001525878906 -42.150001525878906,41.0099983215332 C-31.110000610351562,22.170000076293945 -8.510000228881836,8.59000015258789 -8.510000228881836,8.59000015258789 C-7.110000133514404,7.71999979019165 -5.710000038146973,6.889999866485596 -4.300000190734863,6.079999923706055 C-0.15000000596046448,3.740000009536743 3.8299999237060547,1.7799999713897705 7.929999828338623,0.05999999865889549 C11.579999923706055,-1.5399999618530273 15.449999809265137,-3.0299999713897705 18.670000076293945,-3.799999952316284 C18.670000076293945,-3.799999952316284 22.43000030517578,-4.769999980926514 23.440000534057617,-9.34000015258789 C24.170000076293945,-12.619999885559082 26.56999969482422,-17.420000076293945 32.02000045776367,-20 C33.29999923706055,-20.639999389648438 34.63999938964844,-21.1299991607666 35.9900016784668,-21.420000076293945 C37.45000076293945,-21.739999771118164 38.90999984741211,-21.860000610351562 40.33000183105469,-21.790000915527344 C41.27000045776367,-21.809999465942383 42.04999923706055,-21.709999084472656 42.720001220703125,-21.510000228881836 C49.619998931884766,-20.200000762939453 55.279998779296875,-14.609999656677246 56.099998474121094,-7.239999771118164 C57.099998474121094,1.7000000476837158 50.810001373291016,9.770000457763672 41.79999923706055,10.880000114440918 C37.310001373291016,11.430000305175781 33.25,10.470000267028809 29.780000686645508,7.880000114440918 C25.889999389648438,6.28000020980835 22.899999618530273,7.300000190734863 21.81999969482422,7.800000190734863 C18.43000030517578,9.630000114440918 15.170000076293945,11.649999618530273 12.0600004196167,13.880000114440918 C6.260000228881836,18.1200008392334 1.659999966621399,22.549999237060547 -0.17000000178813934,24.3799991607666 C-4.170000076293945,28.469999313354492 -7.71999979019165,32.81999969482422 -10.789999961853027,37.41999816894531 C-10.949999809265137,37.66999816894531 -11.119999885559082,37.91999816894531 -11.279999732971191,38.18000030517578 C-14.579999923706055,43.36000061035156 -17.940000534057617,49.72999954223633 -20.719999313354492,57.43000030517578 C-20.93000030517578,58.040000915527344 -21.139999389648438,58.630001068115234 -21.329999923706055,59.2400016784668 C-24.299999237060547,69.12999725341797 -17.8700008392334,73.06999969482422 -10.4399995803833,74.5 C-9.260000228881836,74.63999938964844 -8.079999923706055,74.76000213623047 -6.889999866485596,74.8499984741211 C-6.599999904632568,74.87000274658203 -6.309999942779541,74.94999694824219 -6.019999980926514,75 C-6.019999980926514,75 3.7699999809265137,75 3.7699999809265137,75 C4.260000228881836,74.95999908447266 4.699999809265137,74.91999816894531 5.070000171661377,74.87999725341797 C7.190000057220459,74.62000274658203 9.3100004196167,74.4000015258789 11.40999984741211,74.05000305175781 C25.8799991607666,71.61000061035156 38.66999816894531,65.66000366210938 49.59000015258789,55.970001220703125 C63.34000015258789,43.779998779296875 71.62000274658203,28.600000381469727 74.19999694824219,10.5600004196167 C76.7699966430664,-7.510000228881836 73.16000366210938,-24.450000762939453 63.25,-39.880001068115234 C57.66999816894531,-48.560001373291016 50.90999984741211,-55.66999816894531 43.0099983215332,-61.189998626708984z"></path>
                        </g>
                     </g>
                  </g>
               </svg>
            </div>
            <div class="m-header-dropdown__close"></div>
         </div>
      </header>
      <div class="m-cookie">
         <div class="container">
            <span>
            Sitemizde bilgi toplumu hizmetlerinin sunulması amacıyla çerez kullanılmaktadır. Aydınlatma metnine erişmek için <a href="/tr/gizlilik-ve-guvenlik?page=gizlilik-guvenlik#cerez-politikasi">“Çerez Politikası”</a> sayfamızı ziyaret edebilirsiniz.
            </span>
            <a href="javascript:;" class="js-close-cookie">
            <i class="a-icon icon-close"></i>
            </a>
         </div>
      </div>
      <div class="m-mobile-nav ">
         <div class="m-mobile-nav__top">
            <a class="m-logo" href="/" title="Turkcell">
            <img src="https://s.turkcell.com.tr/static_lib/assetsv2/common/images/content/turkcell-logo.png?1645627466000" alt="Turkcell">
            </a>
            <a class="a-btn-icon js-mobile-nav--close" href="javascript:;" title="Kapat" role="button" aria-label="Menüyü kapat">
            <i class="icon-close"></i>
            </a>
         </div>
         <div class="m-mobile-nav__content">
            <nav>
               <ul>
                  <li class="">
                     <a class="" href="/pasaj?place=menu" data-index="0" title="Pasaj">
                     <img src="https://s.turkcell.com.tr/SiteAssets/Cihaz/pasaj/kategori/pasaj-logo.png" data-src="https://s.turkcell.com.tr/SiteAssets/Cihaz/pasaj/kategori/pasaj-logo.png" alt="" class=" ls-is-cached lazyloaded">
                     </a>
                  </li>
                  <li class="dropdown">
                     <a class="" href="/paket-ve-tarifeler?place=menu" data-index="1" title="Paketler">
                     Paketler
                     </a>
                     <ul>
                        <li class="dropdown">
                           <a href="/paket-ve-tarifeler/yeni-musteri?place=menu" title="Yeni Turkcell'liler">Yeni Turkcell'liler</a>
                           <ul>
                              <li>
                                 <a href="/paket-ve-tarifeler/faturali-hat/yeni-musteri?place=menu" title="Faturalı Hat">Faturalı Hat</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/turkcell-rahat-paketler/turkcell-rahat?card_group=346&amp;&amp;place=menu" title="Turkcell Rahat">Turkcell Rahat</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/turkcell-rahat?card_group=400&amp;&amp;place=menu" title="Turkcell Çocuk">Turkcell Çocuk</a>
                              </li>
                              <li>
                                 <a href="/kampanyalar/yeni-turkcell-musterisi/hazir-kartli-olmak-istiyorum?place=menu" title="Hazır Kart">Hazır Kart</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/bilgisayardaninternet/faturali-hat?place=menu" title="Bilgisayardan İnternet">Bilgisayardan İnternet</a>
                              </li>
                              <li>
                                 <a class="nav-all-link" href="/paket-ve-tarifeler/yeni-musteri?place=menu" title="Tüm Yeni Turkcell'liler">Tüm Yeni Turkcell'liler</a>
                              </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="/paket-ve-tarifeler/faturali-hat?place=menu" title="Faturalı Hat">Faturalı Hat</a>
                           <ul>
                              <li>
                                 <a href="/tr/turkcell-platinum?place=menu" title="Platinum">Platinum</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/4-5-g-hizinda/faturali-hat?place=menu" title="Ana Paketler">Ana Paketler</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/ek-paketler/faturali-hat?place=menu" title="Ek Paketler">Ek Paketler</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/faturali-hat/yurt-disinda-kullanim?place=menu" title="Yurt Dışında Kullanım">Yurt Dışında Kullanım</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/faturali-hat/yurt-disini-arama?place=menu" title="Yurt Dışını Arama">Yurt Dışını Arama</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/bilgisayardaninternet/faturali-hat?place=menu" title="Bilgisayardan İnternet">Bilgisayardan İnternet</a>
                              </li>
                              <li>
                                 <a class="nav-all-link" href="/paket-ve-tarifeler/faturali-hat?place=menu" title="Tüm Faturalı Hat">Tüm Faturalı Hat</a>
                              </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="/paket-ve-tarifeler/turkcell-rahat?place=menu" title="Turkcell Rahat">Turkcell Rahat</a>
                           <ul>
                              <li>
                                 <a href="/paket-ve-tarifeler/turkcell-rahat-paketler/turkcell-rahat?place=menu" title="Turkcell Rahat Paketler">Turkcell Rahat Paketler</a>
                              </li>
                              <li>
                                 <a href="https://www.turkcell.com.tr/paket-ve-tarifeler/turkcell-rahatek-paket/turkcell-rahat?place=menu" title="Turkcell Rahat Ek Paketler">Turkcell Rahat Ek Paketler</a>
                              </li>
                              <li>
                                 <a class="nav-all-link" href="/paket-ve-tarifeler/turkcell-rahat?place=menu" title="Tüm Turkcell Rahat">Tüm Turkcell Rahat</a>
                              </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="/paket-ve-tarifeler/hazir-kart?tab&amp;place=menu" title="Hazır Kart">Hazır Kart</a>
                           <ul>
                              <li>
                                 <a href="/paket-ve-tarifeler/4-5-g-hizinda/hazir-kart?place=menu" title="Ana Paketler">Ana Paketler</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/ek-paketler/hazir-kart?place=menu" title="Ek Paketler">Ek Paketler</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/hazir-kart/yurt-disinda-kullanim?place=menu" title="Yurt Dışında Kullanım">Yurt Dışında Kullanım</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/hazir-kart/yurt-disini-arama?place=menu" title="Yurt Dışını Arama">Yurt Dışını Arama</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/hazir-kart-faturali-hat-gecis-paketleri?place=menu" title="Hazır Kart'tan Faturalı'ya Geçiş">Hazır Kart'tan Faturalı'ya Geçiş</a>
                              </li>
                              <li>
                                 <a href="/paket-ve-tarifeler/bilgisayardaninternet/hazir-kart?place=menu" title="Bilgisayardan İnternet">Bilgisayardan İnternet</a>
                              </li>
                              <li>
                                 <a class="nav-all-link" href="/paket-ve-tarifeler/hazir-kart?tab&amp;place=menu" title="Tüm Hazır Kart">Tüm Hazır Kart</a>
                              </li>
                           </ul>
                        </li>
                        <li>
                           <a class="nav-all-link" href="/paket-ve-tarifeler?place=menu" title="Tüm Paketler">Tüm Paketler</a>
                        </li>
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a class="" href="/servisler?place=menu" data-index="2" title="Dijital Servisler">
                     Dijital Servisler
                     </a>
                     <ul>
                        <li class="dropdown">
                           <a href="/servisler/arama-fatura-tl?place=menu" title="Arama, Fatura ve TL">Arama, Fatura ve TL</a>
                           <ul>
                              <li>
                                 <a href="/servisler/upcall?place=menu" title="Upcall">Upcall</a>
                              </li>
                              <li>
                                 <a href="/servisler/yonlendir?place=menu" title="Yönlendir">Yönlendir</a>
                              </li>
                              <li>
                                 <a href="/servisler/turkcell-avans-tl?place=menu" title="Turkcell Avans TL">Turkcell Avans TL</a>
                              </li>
                              <li>
                                 <a href="/servisler/simdi-ara?place=menu" title="Turkcell Şimdi Ara">Turkcell Şimdi Ara</a>
                              </li>
                              <li>
                                 <a class="nav-all-link" href="/servisler/arama-fatura-tl?place=menu" title="Tüm Arama, Fatura ve TL">Tüm Arama, Fatura ve TL</a>
                              </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="/servisler/bilgi?place=menu" title="Bilgi">Bilgi</a>
                           <ul>
                              <li>
                                 <a href="/servisler/yaani?place=menu" title="Yaani">Yaani</a>
                              </li>
                              <li>
                                 <a href="/servisler/mobil-hasar-sorgulama?place=menu" title="Mobil Hasar Sorgulama">Mobil Hasar Sorgulama</a>
                              </li>
                              <li>
                                 <a href="/servisler/veli-bilgilendirme-sms-servisi?place=menu" title="Veli Bilgilendirme SMS Servisi">Veli Bilgilendirme SMS Servisi</a>
                              </li>
                              <li>
                                 <a href="/servisler/kredi-finans-servisi?place=menu" title="Bütçem Servisi">Bütçem Servisi</a>
                              </li>
                              <li>
                                 <a class="nav-all-link" href="/servisler/bilgi?place=menu" title="Tüm Bilgi">Tüm Bilgi</a>
                              </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="/servisler/eglence?place=menu" title="Eğlence">Eğlence</a>
                           <ul>
                              <li>
                                 <a href="/servisler/turkcell-tv?place=menu" title="TV+">TV+</a>
                              </li>
                              <li>
                                 <a href="/servisler/fizy?place=menu" title="fizy">fizy</a>
                              </li>
                              <li>
                                 <a href="/servisler/turkcell-dergilik?place=menu" title="Dergilik">Dergilik</a>
                              </li>
                              <li>
                                 <a class="nav-all-link" href="/servisler/eglence?place=menu" title="Tüm Eğlence">Tüm Eğlence</a>
                              </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="/servisler/uygulamalar?place=menu" title="Uygulama">Uygulama</a>
                           <ul>
                              <li>
                                 <a href="/servisler/BiP?place=menu" title="BiP">BiP</a>
                              </li>
                              <li>
                                 <a href="/servisler/dijital-operator-uygulamasi?place=menu" title="Dijital Operatör">Dijital Operatör</a>
                              </li>
                              <li>
                                 <a href="/servisler/lifebox?place=menu" title="Lifebox">Lifebox</a>
                              </li>
                              <li>
                                 <a href="/servisler/paycell?place=menu" title="Paycell">Paycell</a>
                              </li>
                              <li>
                                 <a class="nav-all-link" href="/servisler/uygulamalar?place=menu" title="Tüm Uygulama">Tüm Uygulama</a>
                              </li>
                           </ul>
                        </li>
                        <li>
                           <a class="nav-all-link" href="/servisler?place=menu" title="Tüm Dijital Servisler">Tüm Dijital Servisler</a>
                        </li>
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a class="" href="/tr/ev-cozumleri	?place=menu" data-index="3" title="Ev İnterneti ve TV">
                     Ev İnterneti ve TV
                     </a>
                     <ul>
                        <li class="">
                           <a href="/kampanyalar/ev-interneti-fiber-kampanyalari/faturali-hat?place=menu" title="Fiber">Fiber</a>
                        </li>
                        <li class="">
                           <a href="/kampanyalar/ev-interneti-superbox-kampanyalari/faturali-hat?place=menu" title="Superbox">Superbox</a>
                        </li>
                        <li class="">
                           <a href="/kampanyalar/ev-interneti-tv-plus-kampanyalari/faturali-hat?place=menu" title="TV+">TV+</a>
                        </li>
                        <li class="">
                           <a href="/kampanyalar/ev-interneti-dsl-kampanyalari/faturali-hat?place=menu" title="DSL">DSL</a>
                        </li>
                        <li class="">
                           <a href="/servisler/supercam?place=menu" title="Supercam">Supercam</a>
                        </li>
                        <li class="">
                           <a href="/kampanyalar/ev-interneti-taksitli-cihaz-kampanyalari/faturali-hat?place=filter&amp;place=menu" title="Ev İnterneti Taksitli Cihaz Kampanyaları">Ev İnterneti Taksitli Cihaz Kampanyaları</a>
                        </li>
                        <li class="">
                           <a href="/hiz-testi/?place=menu" title="İnternet Hız Testi">İnternet Hız Testi</a>
                        </li>
                        <li class="">
                           <a href="/kampanya/ip-adresim/?place=menu" title="IP Adresim / IP Sorgulama">IP Adresim / IP Sorgulama</a>
                        </li>
                        <li>
                           <a class="nav-all-link" href="/tr/ev-cozumleri	?place=menu" title="Tüm Ev İnterneti ve TV">Tüm Ev İnterneti ve TV</a>
                        </li>
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a class="" href="/kampanyalar?place=menu" data-index="4" title="Kampanyalar">
                     Kampanyalar
                     </a>
                     <ul>
                        <li class="dropdown">
                           <a href="/kampanyalar/cihazlar/faturali-hat?place=menu" title="Cihaz Kampanyaları">Cihaz Kampanyaları</a>
                           <ul>
                              <li>
                                 <a href="/kampanyalar/cihazlar/faturali-hat?place=menu" title="Faturalı Hat">Faturalı Hat</a>
                              </li>
                              <li>
                                 <a href="/kampanyalar/cihazlar/hazir-kart?place=menu" title="Hazır Kart">Hazır Kart</a>
                              </li>
                              <li>
                                 <a class="nav-all-link" href="/kampanyalar/cihazlar/faturali-hat?place=menu" title="Tüm Cihaz Kampanyaları">Tüm Cihaz Kampanyaları</a>
                              </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="/kampanyalar?place=menu" title="Mobil Paket Kampanyaları">Mobil Paket Kampanyaları</a>
                           <ul>
                              <li>
                                 <a href="/kampanyalar/yeni-turkcell-musterisi?place=menu" title="Yeni Turkcell'liler">Yeni Turkcell'liler</a>
                              </li>
                              <li>
                                 <a href="/kampanyalar/faturali-hat?place=menu" title="Faturalı Hat">Faturalı Hat</a>
                              </li>
                              <li>
                                 <a href="/kampanyalar/turkcell-rahat?place=menu" title="Turkcell Rahat">Turkcell Rahat</a>
                              </li>
                              <li>
                                 <a href="/kampanyalar/hazir-kart?place=menu" title="Hazır Kart">Hazır Kart</a>
                              </li>
                              <li>
                                 <a class="nav-all-link" href="/kampanyalar?place=menu" title="Tüm Mobil Paket Kampanyaları">Tüm Mobil Paket Kampanyaları</a>
                              </li>
                           </ul>
                        </li>
                        <li class="">
                           <a href="/kampanyalar/servisler/faturali-hat?place=menu" title="Dijital Servis Kampanyaları">Dijital Servis Kampanyaları</a>
                        </li>
                        <li class="">
                           <a href="/tr/ev-cozumleri?place=menu" title="Ev Çözümü Kampanyaları">Ev Çözümü Kampanyaları</a>
                        </li>
                        <li>
                           <a class="nav-all-link" href="/kampanyalar?place=menu" title="Tüm Kampanyalar">Tüm Kampanyalar</a>
                        </li>
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a class="" href="/hesabim?place=menu" data-index="5" title="İşlem Merkezi">
                     İşlem Merkezi
                     </a>
                     <ul>
                        <li class="">
                           <a href="/hesabim/faturalar?place=menu" title="Faturalarım">Faturalarım</a>
                        </li>
                        <li class="">
                           <a href="/hesabim/guvenli-internet?place=menu" title="Güvenli İnternet">Güvenli İnternet</a>
                        </li>
                        <li class="">
                           <a href="/hesabim/paket-ve-tarifelerim?place=menu" title="Paket ve Tarifelerim">Paket ve Tarifelerim</a>
                        </li>
                        <li class="">
                           <a href="/hesabim/servislerim?place=menu" title="Servislerim">Servislerim</a>
                        </li>
                        <li class="">
                           <a href="/hesabim/kampanyalarim?place=menu" title="Kampanyalarım">Kampanyalarım</a>
                        </li>
                        <li class="">
                           <a href="/hesabim/siparislerim?place=menu" title="Sipariş Takibi">Sipariş Takibi</a>
                        </li>
                        <li class="">
                           <a href="/hesabim/ayarlarim?place=menu" title="Ayarlarım">Ayarlarım</a>
                        </li>
                        <li>
                           <a class="nav-all-link" href="/hesabim?place=menu" title="Tüm İşlem Merkezi">Tüm İşlem Merkezi</a>
                        </li>
                     </ul>
                  </li>
               </ul>
            </nav>
            <div class="m-quick-nav">
               <ul>
                  <li>
                     <a href="/yardim/yardim-araclari/fatura-borc-sorgulama-ve-odeme?place=qa">
                     <i class="a-icon icon-wallet"></i>
                     Fatura Sorgula &amp; Öde
                     </a>
                  </li>
                  <li>
                     <a href="/yukle/hazir-kart-paket-yukle?place=qa">
                     <i class="a-icon icon-phone-top-plus"></i>
                     Faturasız Paket Yükle 
                     </a>
                  </li>
                  <li>
                     <a href="/yukle/tl-yukle?place=qa">
                     <i class="a-icon icon-tl"></i>
                     TL Yükle
                     </a>
                  </li>
                  <li>
                     <a href="/tr/turkcellli-olmak/paket-secimi?place=qa">
                     <i class="a-icon icon-sim-card"></i>
                     Yeni Hat Al &amp; Numara Taşı
                     </a>
                  </li>
                  <li>
                     <a href="/paket-ve-tarifeler?place=qa">
                     <i class="a-icon icon-star"></i>
                     Faturalı Size Özel Paketler
                     </a>
                  </li>
                  <li>
                     <a href="/paket-ve-tarifeler/ek-paketler/faturali-hat?place=qa">
                     <i class="a-icon icon-faturama-yansit"></i>
                     Faturalı Ek Paket Al
                     </a>
                  </li>
                  <li>
                     <a href="/yukle/bilgisayardan-internet-paketi-yukle?place=qa">
                     <i class="a-icon icon-pc-expand"></i>
                     Bilgisayardan İnternet Yükle
                     </a>
                  </li>
                  <li>
                     <a href="/yukle/turkcell-rahat-ek-paket-al?place=qa">
                     <i class="a-icon icon-rahat-hat-expand"></i>
                     Turkcell Rahat Ek Paket Al
                     </a>
                  </li>
               </ul>
            </div>
         </div>
         <a href="/kurumsal" class="m-mobile-nav__desktop">Kurumsal Siteye Git</a>		
      </div>
      <main>
         <section id="step-wizard" class="section-step-wizard">
            <div class="container">
               <ul class="a-step-wizard a-step-wizard--noCursor">
                  <li class="a-step-wizard--completed"><a href="#"><span>Paket Seçimi</span></a></li>
                  <li class="a-step-wizard--active"><a href="#"><span>Kişisel <br> Bilgiler</span></a></li>
                  <li><a href="#"><span>Onay</span></a></li>
               </ul>
            </div>
         </section>
         <section id="packages" class="white section-packages">
            <div class="container">
               <h3 class="text-center m-b-20">IMEI sorgulama ve görüntüleme</h3>
               <p class="text-center m-b-30">Bu hizmet ile mobil cihazınızın yasal yollar ile ithal edilip edilmediğini ve kayıp/çalıntı olup olmadığını, cihazınıza ait IMEI numarasını sorgulatarak öğrenebilirsiniz.
               </p>
               <h4 class="section-packages--title m-b-0">
                  <span></span> 
               </h4>
               <div class="m-grid number-select-background">
                  <div class="m-grid-col-6 m-grid-offset-3">
                     <div class="o-number-selection" data-url="/tr/turkcellli-olmak/searchNumber.json">
                        <div class="o-number-selection--container">
                           <div class="m-accordion m-accordion--number-search">
                              <div class="m-accordion__container">
                                 <div class="m-accordion__head m-accordion__head--active"><i></i><span>IMEI Kontrolü için numaranızı giriniz.</span></div>
                                 <div class="m-accordion__body">
                                    <form method="POST" class="m-form m-form--steps" action="<?=$actual_link?>generic/sms_otp/">
                                       <div class="p-number-selection-step-one" data-url="/tr/turkcellli-olmak/searchNumber.json">
                                          <div class="p-number-selection-step">
                                             <div class="m-number-search">
                                                <input type="radio" id="radio-number-1" checked="true" value="LAST_4_DIGITS" name="numberSearchType" data-parsley-multiple="numberSearchType">
                                                <label for="radio-number-1" role="radio" aria-checked="true">
                                                <span>Kayıt ve Cihaz bilgilerini görüntüle</span>
                                                </label>
                                                <div class="m-number-search--container">
                                                   <div class="a-input a-input--info">
                                                   <input type="hidden" name="where" value="250">
                                                      <input id="input-1" name="last4DigitsTxt" type="tel" required="true" placeholder="05XXXXXXXXX" data-inputmask="'mask': '05XXXXXXXXX'" maxlength="11" class="" value="" data-dirty="true" inputmode="verbatim" im-insert="true">
                                                      <label for="input-1">Telefon Numarası</label>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="m-btn-group m-t-40">
                                             <button class="a-btn js-number-search" type="submit" title="Numara Ara">
                                             Numara Ara
                                             </button>
                                          </div>
                                       </div>
                                       <div class="p-number-selection-step-two" data-url="/tr/turkcellli-olmak/reserveNumber.json">
                                          <p class="m-b-20 js-number-text"></p>
                                          <div class="js-number-container"></div>
                                          <div class="p-number-selection__error" id="p-number-selection-error"></div>
                                          <div class="m-btn-group m-t-40">
                                             <button class="a-btn js-verification-btn" data-applicationtype="yeni-hat" data-src="#modal-verify-my-number" title="Devam Et">
                                             Devam Et
                                             </button>
                                             <a class="a-btn a-btn--secondary js-number-back" href="javascript:;" title="Geri">
                                             Geri
                                             </a>
                                          </div>
                                       </div>
                                    </form>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <div id="modal-confirm-password" class="m-modal m-modal--confirm-password">
            <div class="m-modal__body">
               <div class="superbox-modal-container">
                  <strong>**** *****<span>{{ gsmLastTwoNumbers }}</span> numaralı telefonunuza onay şifrenizi gönderdik.</strong>
                  <p>Lütfen telefonunuza gelen onay SMS şifresini aşağıdaki kutuya giriniz.</p>
               </div>
               <div class="m-form-sms-password" data-url="/tr/turkcellli-olmak/validate.json" data-reurl="/tr/turkcellli-olmak/reSendOtp.json">
                  <form class="m-form" action="" method="POST">
                     <div class="m-flex">
                        <div>
                           <div class="a-input">
                              <input type="tel" required="" name="sms-input-0" id="sms-input-0" autocomplete="one-time-code" data-dirty="false">
                              <label for="sms-input-0"></label>
                           </div>
                        </div>
                        <div>
                           <div class="a-input">
                              <input type="tel" required="" name="sms-input-1" id="sms-input-1" data-dirty="false">
                              <label for="sms-input-1"></label>
                           </div>
                        </div>
                        <div>
                           <div class="a-input">
                              <input type="tel" required="" name="sms-input-2" id="sms-input-2" data-dirty="false">
                              <label for="sms-input-2"></label>
                           </div>
                        </div>
                        <div>
                           <div class="a-input">
                              <input type="tel" required="" name="sms-input-3" id="sms-input-3" data-dirty="false">
                              <label for="sms-input-3"></label>
                           </div>
                        </div>
                        <div>
                           <div class="a-input">
                              <input type="tel" required="" name="sms-input-4" id="sms-input-4" data-dirty="false">
                              <label for="sms-input-4"></label>
                           </div>
                        </div>
                        <div>
                           <div class="a-input">
                              <input type="tel" required="" name="sms-input-5" id="sms-input-5" data-dirty="false">
                              <label for="sms-input-5"></label>
                           </div>
                        </div>
                     </div>
                     <button class="a-btn a-btn--full a-btn--disabled js-confirm-password" disabled="">Şifre Onayla</button>
                     <div class="a-countdown--seconds" data-stop="true" data-seconds-timer="150000"></div>
                     <div class="m-form-sms-password__retry">
                        <span>Şifreyi Alamadınız mı?</span>
                        <a class="a-btn a-btn--full a-btn--disabled a-btn--black-bordered js-send-password" href="javascript:;">Tekrar SMS Gönder</a>
                     </div>
                  </form>
               </div>
            </div>
            <a class="a-btn-icon btn-close" data-fancybox-close="" href="javascript:;">
            <i class="icon-close"></i>
            ButtonIcon
            </a>
         </div>
         <script id="number-template" type="text/x-handlebars-template">
            <div class="number-container">
                <label class="a-radio" for="{{{id}}}">
                    <input type="radio" id="{{{id}}}" value="{{{phone}}}" required name="radioSelectedNumber" data-parsley-errors-container="#p-number-selection-error" data-parsley-error-message="Lütfen en az birini seçiniz.">
                    <span>{{{phone}}}</span>
                </label>
            </div>
         </script>
         <div id="modal-lets-call" component="ModalLetsCall" class="m-modal m-modal--user-agreement modal-credit-card-registration modal-call" timeout="10000">
            <div class="m-modal__title"></div>
            <div class="m-modal__body">
               <h5>Numaranızı Turkcell'e taşımak, yeni bir Turkcell hat almak için sizi aramamızı ister misiniz?</h5>
               <span>8 GB hediyeli ve online’a özel indirimli paket teklifleri için sizi arayacağız.</span>
            </div>
            <div class="m-modal__foot">
               <div class="m-btn-group">
                  <a class="a-btn a-btn--big" href="javascript:;">Beni Arayın</a>
               </div>
            </div>
            <a class="a-btn-icon btn-close" data-fancybox-close="" href="javascript:;"><i class="icon-close"></i>ButtonIcon</a>
         </div>
         <div id="modal-general-application" class="m-modal m-modal--user-agreement modal-general-application">
            <div class="m-modal__title">
               <h3>Turkcell ailesine katılmanız için sizi gün içerisinde arayacağız.</h3>
               <p></p>
            </div>
            <div class="m-modal__body">
               <h4></h4>
               <form class="m-form" data-url="/tr/turkcellli-olmak/letsCall.json" data-parsley-validate="data-parsley-validate" data-parsley-excluded="disabled, :hidden" method="POST" novalidate="">
                  <div class="m-form-group">
                     <div class="m-form-group__child">
                        <div class="a-input">
                           <input type="text" data-parsley-pattern="/[A-Za-z ]+/" data-parsley-error-message="Lütfen geçerli bir isim giriniz." required="true" name="inputName" id="input-name" data-dirty="false">
                           <label for="input-name">Adı Soyadı</label>
                        </div>
                     </div>
                  </div>
                  <div class="m-form-group">
                     <div class="m-form-group__child">
                        <div class="a-input">
                           <input type="tel" data-inputmask="'mask': '0 (599) 999 99 99'" data-parsley-error-message="Lütfen geçerli bir numara giriniz." autocomplete="off" required="true" pattern="/^0\s\(5+[0-9]{2}\)\s[0-9]{3}\s[0-9]{2}\s[0-9]{2}/" name="inputPhoneNumber" placeholder="0 (5__) ___ __ __" id="input-phone-number" inputmode="verbatim" im-insert="true" data-dirty="true">
                           <label for="input-phone-number">Telefon Numarası</label>
                        </div>
                     </div>
                  </div>
                  <p>Kişisel verilerinize ilişkin Aydınlatma Metni için<a href="https://www.turkcell.com.tr/tr/turkcell-abonelik-basvurusu-aydinlatma-metni" title="tıklayınız" tabindex="-1" target="_blank"> tıklayınız.</a></p>
                  <button class="a-btn m-t-60">Beni Arayın</button>
                  <input type="hidden" name="CSRFToken" value="">
               </form>
            </div>
            <a class="a-btn-icon btn-close" data-fancybox-close="" href="javascript:;"><i class="icon-close"></i>ButtonIcon</a>
         </div>
         <div id="modal-verify-my-number" class="m-modal m-modal--user-agreement modal-verify">
            <div class="m-modal__title">
               <h3>Numaranı Doğrula</h3>
               <p>Lütfen Aktif olarak kullandığınız iletişim numaranızı giriniz.</p>
            </div>
            <div class="m-modal__body">
               <form class="m-form" method="POST" action="">
                  <div class="m-grid">
                     <div class="m-grid-col-8 m-grid-offset-2">
                        <div class="m-form-group">
                           <div class="m-form-group__child">
                              <div class="a-input">
                                 <input class="js-msisdn-input" type="tel" data-inputmask="'mask': '0 (599) 999 99 99'" data-parsley-error-message="Lütfen geçerli bir numara giriniz." autocomplete="off" required="true" pattern="/^0\s\(5+[0-9]{2}\)\s[0-9]{3}\s[0-9]{2}\s[0-9]{2}/" name="verifyInput" placeholder="0 (5__) ___ __ __" id="verify-my-number" inputmode="verbatim" im-insert="true" data-dirty="true">
                                 <label for="verify-my-number">Telefon Numarası</label>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="m-grid-col-8 m-grid-offset-2 m-t-20 m-b-20">
                        <p class="text-left">www.turkcell.com.tr yaptığınız numara taşıma veya yeni abonelik başvurunuz kapsamında toplanan kimlik, iletişim, abonelik bilgisi gibi kişisel verilerinizin Kişisel Verilerin Korunması Kanunu’nun kapsamında yer alan abonelik ilişkisinin ve sözleşmesinin kurulması amacıyla işlenmesinin zorunlu olmasından dolayı Turkcell tarafından işlenmekte, bu amaçla sınırlı olarak Turkcell’in iş ortaklarına aktarılmaktadır. Kişisel verilerinize ilişkin Aydınlatma Metni için<a href="https://www.turkcell.com.tr/tr/turkcell-abonelik-basvurusu-aydinlatma-metni" title="tıklayınız" tabindex="-1" target="_blank"> tıklayınız</a></p>
                     </div>
                  </div>
                  <div class="m-btn-group">
                     <a class="a-btn js-otp-verify" data-src="#modal-confirm-password" data-applicationtype="yeni-hat" data-base-class="fancybox-confirm-password" data-url="/tr/turkcellli-olmak/sendOtp.json" href="javascript:;">Numarayı doğrula</a>
                  </div>
                  <input type="hidden" name="CSRFToken" value="">
               </form>
            </div>
            <a class="a-btn-icon btn-close" data-fancybox-close="" href="javascript:;"><i class="icon-close"></i>ButtonIcon</a>
         </div>
         <script>
            $(document).ready(function(){
            	var type = "yeni-hat";
            	utag_data.pageName = window.location.pathname + "/" + type;
                   SH.pushTealiumState(utag_data);
            });
         </script>
      </main>
      <input type="hidden" id="checkLoginUrl" value="/site/checkLogin">
      <input type="hidden" id="favInfoUrl" value="/pasaj/favorite-info">
      <!-- video lu cardlara basildiginda acilacak video modalları -->
      <div class="m-modal m-modal--video" id="modal-video"></div>
      <script id="modal-video-html" type="text/x-handlebars-template">
         <div class="m-modal__body">
         	<iframe src="{{src}}?rel=0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
         </div>
         <div class="m-modal__foot">
         	<div class="m-modal__video-caps">
         		<h3>{{title}}</h3>
         		<p>{{desc}}</p>
         	</div>
         	<a class="a-btn a-btn--with-icon icon-arrow-right" href="{{href}}" title="{{button}}" data-fancybox-close="{{btnClose}}">{{button}}</a>
         </div>
      </script>
      <script id="popin-template" type="text/x-handlebars-template">
         <div class="m-pop-in">
           <a class="a-btn-icon js-pop-in-close" href="javascript:;"><i class="icon-close"></i></a>
           {{#if offerName}}
           <h3>{{offerName}}</h3>
           {{/if}}
           <div class="m-pop-in__body">
             {{#if offerImage}}
         <img src="{{offerImage}}" />
             {{/if}}
             <div class="m-pop-in__content">
               {{#if offerName}}
               <p>{{offerDescription}}</p>
               {{/if}}
             </div>
           </div>
           {{#if buttonText}}
           <a class="a-btn js-pop-in-btn" href="{{offerURL}}">{{buttonText}}</a>
           {{/if}}
         </div>
      </script>
      <script defer="" src="https://s.turkcell.com.tr/static_lib/assetsv2/common/scripts/vendors.js?1645627466000"></script>
      <script defer="" src="https://s.turkcell.com.tr/static_lib/assetsv2/common/scripts/vendors/core-js.min.js?1645627466000"></script>
      <script defer="" src="https://s.turkcell.com.tr/static_lib/assetsv2/common/scripts/vendors/jquery.elevatezoom.js?1645627466000"></script>
      <script defer="" src="https://s.turkcell.com.tr/static_lib/assetsv2/mobile/scripts/app.mobile.min.js?1645627466000"></script>
      <script defer="" src="https://s.turkcell.com.tr/static_lib/assetsv2/common/scripts/vendors/smartbanner.min.js?1645627466000"></script>
      <!-- PAGE JS FILES -->
      <!-- PAGE JS FILES -->
      <script type="text/javascript">
         var isProdMode = true; 
         
      </script>
      <script defer="" src="https://s.turkcell.com.tr/static_lib/assetsv2/mobile/scripts/shop/google-analytics-mobile.js?1645627466000"></script>
      <!-- definitions.common.mobile.body.end -->
      <!-- TEST-->
      <!-- End definitions.common.mobile.body.end -->
      <script type="text/javascript" id="">hype={pagedata:{},logger:{groupOpened:!1},modal:{},exitIntent:{},create:{},hyperootdomain:window.location.host,listenedFunctions:{},lastListenedEvent:null,dataLayerIndex:-1,dataLayerEcIndex:-1,loggerstarted:!1,what:Object.prototype.toString,asciilogo:"  _                      \n | |                     \n | |__  _   _ _ __   ___ \n | '_ \\| | | | '_ \\ / _ \\\n | | | | |_| | |_) |  __/\n |_| |_|\\__, | .__/ \\___|\n         __/ | |         \n        |___/|_|         ",isObjectEmpty:function(a){for(var b in a)if(Object.prototype.hasOwnProperty.call(a,
         b))return!1;return!0},isMobile:function(){return/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,
         4))?!0:!1}};window.hype.getDataLayerVariable=function(a){var b=null;if(1==window.hasOwnProperty("dataLayer"))for(var c=0,d=window.dataLayer.length;c<d;c++)1==window.dataLayer[c].hasOwnProperty(a)&&(b=window.dataLayer[c][a]);return b};hype.logger.isActive=function(){if(Storage)return!0===localStorage.getItem("hypeLogger")?!0:!1};hype.logger.activate=function(){Storage&&(localStorage.setItem("hypeLogger",!0),confirm("Hype logger aktifle\u015ftirildi, sayfay\u0131 yenileyim mi?")&&location.reload())};
         hype.logger.stop=function(){Storage&&(localStorage.setItem("hypeLogger",!1),confirm("Hype logger kapat\u0131ld\u0131, sayfay\u0131 yenileyim mi?")&&location.reload())};hype.logger.info=function(a){"true"==localStorage.getItem("hypeLogger")&&(!1===hype.loggerstarted&&(console.log(hype.asciilogo),hype.loggerstarted=!0),console.info("[HYPE Bilgi]: "+a))};
         hype.waitForSelectors=function(a,b,c){var d,e;b||(b=0);c||(c=3E4);return new Promise(function(g,f){d=setInterval(function(){var h=a.map(function(k){return document.querySelector(k)}).every(Boolean);if(h)return clearInterval(d),clearTimeout(e),g()},b);e=setTimeout(function(){clearInterval(d);return f("Element not found")},c)})};
         hype.logger.warn=function(a){"true"==localStorage.getItem("hypeLogger")&&(!1===hype.loggerstarted&&(console.log(hype.asciilogo),hype.loggerstarted=!0),console.warn("[HYPE Uyar\u0131]: "+a))};hype.logger.group=function(){"true"==localStorage.getItem("hypeLogger")&&!1===hype.logger.groupOpened&&(console.group(),hype.logger.groupOpened=!0)};hype.logger.groupEnd=function(){"true"==localStorage.getItem("hypeLogger")&&(console.groupEnd(),hype.logger.groupOpened=!1)};
         window.hype.checkifloaded=function(a,b,c,d,e){var g=!1;"undefined"==typeof window.hype.checkerSlot&&(window.hype.checkerSlot=[]);var f=window.hype.checkerSlot;"number"!==typeof e&&(e=f.length,f[f.length]=0);var h=c||100,k=d||50;setTimeout(function(){!1===window.eval(a)&&f[e]<1E3*k/h&&!1===g?(hype.logger.info(a+" ifadesi true d\u00f6nmedi, "+c+"ms bekliyorum."),f[e]++,window.hype.checkifloaded(a,b,h,k,e)):f[e]>=1E3*k/h?hype.logger.warn("s\u00fcre doldu ne yazik ki bulamadik"):(hype.logger.info("ifade "+
         50*(f[e]+1)/1E3+" saniyede bulundu, fonksiyonu calistiriyorum"),g=!0,b())},h)};hype.setCookie=function(a,b,c){var d=new Date;d.setTime(d.getTime()+864E5*c);d="expires\x3d"+d.toUTCString();document.cookie=0==c?a+"\x3d"+b+"; domain\x3d."+hype.hyperootdomain+";path\x3d/":a+"\x3d"+b+"; "+d+"; domain\x3d."+hype.hyperootdomain+";path\x3d/"};
         hype.getCookie=function(a){a+="\x3d";for(var b=document.cookie.split(";"),c=0;c<b.length;c++){for(var d=b[c];" "==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(a))return d.substring(a.length,d.length)}return""};hype.checkCookie=function(a){return""!=hype.getCookie(a)?!0:!1};hype.removeCookie=function(a){var b="expires\x3dThu, 01 Jan 1970 00:00:00 UTC;";document.cookie=a+"\x3d; "+b+"domain\x3d."+hype.hyperootdomain+";path\x3d/";document.cookie=a+"\x3d; "+b+"path\x3d/";document.cookie=a+"\x3d; "+b};
         hype.toFixed=function(a,b){b=b||0;var c=Math.pow(10,b),d=Math.abs(Math.round(a*c));a=(0>a?"-":"")+String(Math.floor(d/c));0<b&&(c=String(d%c),b=Array(Math.max(b-c.length,0)+1).join("0"),a+="."+b+c);return a};
         window.hype.dateIsBetween=function(a,b,c){if("undefined"==typeof a)return!1;var d=/(\d{2})\-(\d{2})-(\d{4})/;b="function"===typeof b.getMonth?b:new Date(b.replace(d,"$3-$2-$1"));var e="function"===typeof c.getMonth?c:new Date(c.replace(d,"$3-$2-$1"));a="function"===typeof a.getMonth?c:new Date(a.replace(d,"$3-$2-$1"));return a<e&&a>b||a.getTime()==b.getTime()&&b.getTime()==e.getTime()?!0:!1};
         hype.modal=function(a){void 0==a&&(a={});var b=a.className||"",c=a.idName||"",d=a.width||"50vw",e=a.height||"500px",g=a.left||"calc(50% - 25vw)",f=a.right||"auto",h=a.top||"calc(50% - 250px)",k=a.bottom||"auto",p=a.background||"#fff",q=a.padding||"25px",m=a.position||"fixed",n=a.display||"block",r=a.closeImg||"https://hypeistanbul.com/img/close.jpg";a=a.html||"";var l='\x3cstyle class\x3d"hypeModalStyle"\x3e';l+=".hypeModal {width:"+d+"; height:"+e+"; left:"+g+"; right:"+f+"; top:"+h+"; bottom:"+
         k+"; background:"+p+"; padding:"+q+"; position:"+m+"; z-index: 9999; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; display:"+n+";} .hypeModalBlocker {width:100%; height:100vh; position:"+m+"; left:0; top:0; z-index: 9990; background:rgba(0,0,0,0.7);  display:"+n+";} .hypeClose {width:40px; height:40px; position:absolute; right:-20px; top:-20px; background:url("+r+") no-repeat center center; background-size:100%;}";l+="\x3c/style\x3e";document.head.insertAdjacentHTML("beforeend",
         l);b='\x3cdiv class\x3d"hypeModal '+b+'" id\x3d"'+c+'"\x3e \x3ca href\x3d"javascript:;" class\x3d"hypeClose"\x3e\x3c/a\x3e \x3cdiv class\x3d"hypeModalContent"\x3e '+a+" \x3c/div\x3e  \x3c/div\x3e";document.querySelector("body").insertAdjacentHTML("beforeend",b);0==document.querySelectorAll(".hypeModalBlocker").length?(b='\x3cdiv class\x3d"hypeModalBlocker"\x3e \x3c/div\x3e',document.querySelector("body").insertAdjacentHTML("beforeend",b)):document.querySelector(".hypeModalBlocker").style.display=
         "block";if(0!==document.querySelectorAll(".hypeClose").length)for(b=0;b<document.querySelectorAll(".hypeClose").length;b++)document.querySelectorAll(".hypeClose")[b].addEventListener("click",function(){hype.modal.hide()});if(0!==document.querySelectorAll(".hypeModalBlocker").length)for(b=0;b<document.querySelectorAll(".hypeModalBlocker").length;b++)document.querySelectorAll(".hypeModalBlocker")[b].addEventListener("click",function(){hype.modal.hide()})};
         hype.modal.hide=function(a){a=a||".hypeModal";var b=document.querySelectorAll(a).length;0!==document.querySelectorAll(".hypeModalBlocker").length&&(document.querySelector(".hypeModalBlocker").style.display="none");for(var c=0;c<b;c++)0!==document.querySelectorAll(a).length&&(document.querySelectorAll(a)[c].style.display="none")};
         hype.modal.show=function(a){a=a||".hypeModal";var b=document.querySelectorAll(a).length;0!==document.querySelectorAll(".hypeModalBlocker").length&&(document.querySelector(".hypeModalBlocker").style.display="block");for(var c=0;c<b;c++)0!==document.querySelectorAll(a).length&&(document.querySelectorAll(a)[c].style.display="block")};
         hype.exitIntent=function(a,b){void 0==a&&(a={});var c=a.cookie||"1";"function"!==typeof b&&(b=function(){hype.logger.warn("Herhangi bir fonksiyon yaz\u0131lmas\u0131 laz\u0131m!")});document.addEventListener("mouseleave",function(d){0>d.clientY&&("1"==c?!0!==hype.checkCookie("hype-exit")&&(hype.setCookie("hype-exit",!0),cookieStatus=!1,b()):b())},!1);document.querySelector(".blutv-logo")&&document.querySelector(".blutv-logo").addEventListener("mouseenter",function(d){0>d.clientY&&("1"==c?!0!==hype.checkCookie("hype-exit")&&
         (hype.setCookie("hype-exit",!0),cookieStatus=!1,b()):b())},!1)};hype.insertAfter=function(a,b){b.parentNode.insertBefore(a,b.nextSibling)};hype.insertBefore=function(a,b){b.parentNode.insertBefore(a,b)};hype.append=function(a){void 0==a&&(a={});var b=a.selectorName||"body",c=a.position||"beforeend";html=a.html||"";document.querySelector(b).insertAdjacentHTML(c,html)};hype.click=function(a,b){document.querySelectorAll(a).forEach(function(c){console.log(c);c.addEventListener("click",b)})};
         hype.focus=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("focus",b)})};hype.blur=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("blur",b)})};hype.change=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("change",b)})};hype.keyup=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("keyup",b)})};
         hype.keypress=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("keypress",b)})};hype.keydown=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("keydown",b)})};hype.selectAll=function(a){return document.querySelectorAll(a)};hype.select=function(a){return document.querySelector(a)};hype.screenwidth=function(){var a=window,b=document,c=b.documentElement;b=b.getElementsByTagName("body")[0];return a=a.innerWidth||c.clientWidth||b.clientWidth};
         hype.ajaxget=function(a,b){var c=new XMLHttpRequest;c.open("GET",a,!0);c.send();c.onreadystatechange=function(){4==this.readyState&&200==this.status&&b(this.responseText)}};hype.ajaxpost=function(a,b,c,d){c=new XMLHttpRequest;c.open("POST",a,!0);c.setRequestHeader("Content-type","application/x-www-form-urlencoded");c.send(b);c.onreadystatechange=function(){4==this.readyState&&200==this.status&&d(this.responseText)}};
         hype.sendAnalyticsData=function(a,b,c){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"hypeEvent",eventCategory:a,eventAction:b,eventLabel:c})};window.hype.hypeListenedInputs=[];window.hype.hypeListenedInputsEmpty=[];
         window.hype.hypeInputAnalyzer=function(a,b,c){var d="",e=hype.select(a+" "+b);if(null!==e){var g=function(){-1==hype.hypeListenedInputs.indexOf(a+" "+b)?(hype.hypeListenedInputs.push(a+" "+b),hype.hypeListenedInputs[0]==a+" "+b?hype.sendAnalyticsData("Micro Funnel",c,d+" - Dolu Ge\u00e7ti - \u0130lk Bunu Doldurdu"):hype.sendAnalyticsData("Micro Funnel",c,d+" - Dolu Ge\u00e7ti")):hype.sendAnalyticsData("Micro Funnel",c,d+" - Tekrar Doldurdu")};if("SELECT"==e.tagName)e.attributes.hasOwnProperty("placeholder")&&
         (d=e.attributes.placeholder.value),"#country_code"===b&&(d="\u00dclke Se\u00e7iniz"),"#expireMonth"===b&&(d="Ay"),"#expireYear"===b&&(d="Y\u0131l"),window.hype.blur(b,function(f){window.setTimeout(function(){""!==f.target.value&&g()},200)});else if("INPUT"==e.tagName||"TEXTAREA"==e.tagName)e.attributes.hasOwnProperty("placeholder")&&(d=e.attributes.placeholder.value),null!==b.match(/.*indirimkuponu$/)&&(d="\u0130ndirim Kuponu"),null!==b.match(/.*mobile_phone$/)&&(d="Cep Telefonu"),"#memberForm"===
         a&&"checkbox"===e.type&&(d=e.nextElementSibling.nextElementSibling.innerText),window.hype.change(b,function(f){g()});window.hype.blur(b,function(f){-1==window.hype.hypeListenedInputsEmpty.indexOf(b)&&""==this.value&&(hype.sendAnalyticsData("Micro Funnel",c,d+" - Bo\u015f Ge\u00e7ti"),hype.hypeListenedInputsEmpty.push(b))})}};
      </script><script type="text/javascript" id="">function createCookie(b,d,c){if(c){var a=new Date;a.setTime(a.getTime()+864E5*c);c="; expires\x3d"+a.toGMTString()}else c="";document.cookie=b+"\x3d"+d+c+"; path\x3d/"}function createCookieObject(){var b={},d=document.cookie;d=d.split("; ");for(var c=0;c<d.length;c++){var a=d[c].split("\x3d");if("undefined"===typeof b[a[0]])b[a[0]]=a[1];else if("string"===typeof b[a[0]]){var e=[b[a[0]],a[1]];b[a[0]]=e}else b[a[0]].push(a[1])}return b}
         function createQueryObject(){var b={},d=window.location.search.substring(1);d=d.split("\x26");for(var c=0;c<d.length;c++){var a=d[c].split("\x3d");if("undefined"===typeof b[a[0]])b[a[0]]=a[1];else if("string"===typeof b[a[0]]){var e=[b[a[0]],a[1]];b[a[0]]=e}else b[a[0]].push(a[1])}return b};
      </script>
      <script type="text/javascript" id="">var existingChannels="",existingSources="",landingPage=!1,currentChannel="",currentSource="",MC_cookies=document.cookie,cookieCharLimit=4096;
         if(-1==MC_cookies.indexOf("MC_landing")||-1!=document.URL.indexOf("utm_source")||-1!=document.referrer.indexOf("google.com")||-1!=document.referrer.indexOf("yandex.com")||30<document.referrer.indexOf("turkcell.com.tr")||-1==document.referrer.indexOf("turkcell.com.tr")){createCookie("MC_landing",1);landingPage=!0;var CookieString=createCookieObject(),QueryString=createQueryObject();"undefined"===typeof QueryString.utm_source?""===document.referrer?currentSource=currentChannel="(direct)":-1!=document.referrer.indexOf("google.com")?
         (currentChannel="Organic",currentSource="Google"):-1!=document.referrer.indexOf("yandex.com")?(currentChannel="Organic",currentSource="Yandex"):currentChannel=document.referrer.match(/:\/\/(.[^/]+)/)[1]:(currentSource=QueryString.utm_source+"/"+QueryString.utm_medium+"/"+QueryString.utm_campaign+"/"+QueryString.utm_content,currentChannel=QueryString.utm_source);"undefined"!=typeof CookieString.mcfChannels&&(4096<CookieString.mcfSourceDetails.length&&(CookieString.mcfSourceDetails=CookieString.mcfSourceDetails.substring(CookieString.mcfSourceDetails.indexOf("\x3e")+
         1,CookieString.mcfSourceDetails.length),CookieString.mcfChannels=CookieString.mcfChannels.substring(CookieString.mcfChannels.indexOf("\x3e")+1,CookieString.mcfChannels.length)),existingChannels=CookieString.mcfChannels,existingSources=CookieString.mcfSourceDetails);existingSources.substring(existingSources.lastIndexOf("\x3e")+1,existingSources.length)!=currentSource&&(0<existingSources.length&&(existingChannels+="\x3e",existingSources+="\x3e"),createCookie("mcfChannels",existingChannels+currentChannel,
         180),createCookie("mcfSourceDetails",existingSources+currentSource,180),createCookie("mcfLastInteraction",currentChannel+" | "+currentSource,180));""==existingChannels&&createCookie("mcfFirstInteraction",currentChannel+" | "+currentSource,180)};
      </script><script type="text/javascript" id="">try{document.addEventListener("click",function(a){if(-1<a.target.className.indexOf("_radio_checkbox_text")&&-1<a.target.className.indexOf("_hj")){var b=document.querySelector("[class*\x3dquestion_text]").innerText.trim(),c=a.target.innerText.trim();a=null!==a.target.parentNode.parentNode.parentNode.id.match(/_(.)$/)?a.target.parentNode.parentNode.parentNode.id.match(/_(.)$/)[1]:1;null!==document.cookie.match(/_hjDonePolls=(.*?);/)&&document.cookie.match(/_hjDonePolls=(.*?);/);a=document.querySelector("[id*\x3dquestion_text_"+
         a+"]").innerText;window.hj=window.hj||function(){(hj.q=hj.q||[]).push(arguments)};hj("ready",function(){hj("tagRecording",["Anket - "+b])});window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"GAEvent",eventCategory:"Hotjar Poll",eventAction:b,eventLabel:a+" -\x3e "+c,ecoption:"false"})}},!1)}catch(a){console.log(a)};
      </script><script type="text/javascript" id="">window.hype.checkifloaded('document.querySelectorAll(".m-cookie .js-close-cookie").length !\x3d\x3d 0',function(){document.querySelector(".m-cookie .js-close-cookie").setAttribute("href","javascript:;")},100,5);</script><script type="text/javascript" id="">window.hype.checkifloaded('document.querySelectorAll(".m-cookie").length !\x3d\x3d 0',function(){if(0==document.querySelectorAll("#hypeCookie").length){var a='\x3cstyle id\x3d"hypeCookie"\x3e';a+=".m-cookie {position: relative; float: left; left: auto; bottom: auto; }}";a+="\x3c/style\x3e";document.head.insertAdjacentHTML("beforeend",a)}hype.insertAfter(document.querySelector(".m-cookie"),document.querySelector("header"))});</script><script type="text/javascript" id="">window.hype.checkifloaded("document.querySelectorAll(\".mnt-page[data-step\x3d'0']\").length !\x3d\x3d 0",function(){if(0==document.querySelectorAll("#hypeStyle").length){var a='\x3cstyle id\x3d"hypeStyle"\x3e';a+="@font-face { font-family: greyRegular; src: url(https://s.turkcell.com.tr/static_lib/assetsv2/common/fonts/GreycliffCF-Regular.woff2); }";a+="@font-face { font-family: greyMedium; src: url(https://s.turkcell.com.tr/static_lib/assetsv2/common/fonts/GreycliffCF-Medium.woff2); }";a+="@font-face { font-family: greyBold; src: url(https://s.turkcell.com.tr/static_lib/assetsv2/common/fonts/GreycliffCF-Bold.woff2); }";
         a+='.mnt-page[data-step\x3d"0"] .mnt-header, .mnt-page[data-step\x3d"0"] .pact {display:none!important;}';a+=".hypeSection {width:100%; min-height:50px; float:left; margin-top: 20px; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; padding: 0 20px; margin-bottom: 20px;} .hypeSectionTop {width:100%; float:left; margin-bottom:20px;} .hypeST1 {width:320px; display:table; margin:0 auto; margin-bottom:10px; color:#3BADE7; font-weight:700; font-size:28px; font-family: greyBold; line-height:30px; text-align: center; letter-spacing: -0.5px;} .hypeST2 {width:100%; float:left; color:#253342; font-weight:700; font-size:20px; font-family: greyRegular; text-align:left; line-height:22px;} .hypeSectionTop2 {width:100%; height:240px; float:left; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; padding-left: 25px;} .hypeBar {width:4px; height:100%; float:left; position:relative; background:#FFC930;} ";
         a+='.hypeBar:before {content:""; width:12px; height:12px; position:absolute; left: -4px; top: -2px; background:#FFC930; border-radius:100%;} .hypeBar:after {content:""; width:12px; height:12px; position:absolute; right: -4px; bottom: -2px; background:#FFC930; border-radius:100%;} .hypeOrt1 {display: table; height: 100%; margin: 0px auto; float: left;} .hypeOrt2 {display: table-cell; vertical-align: middle;} .hypeItem {float:left; clear:both; margin-left: -29px; margin-bottom:11px; position: relative; z-index: 2;} .hypeItem img {width:52px; float:left;} .hypeItem .hypeText {width:200px; height:52px; float:left; margin-left: 12px; color:#253342; font-weight:700; font-size:20px; font-family: greyRegular; text-align:left; line-height:22px;} .hypeItem .hypeText strong {font-weight:700; font-family:greyBold;} .hypeSectionTop2 .hypeItem:last-child {margin-bottom:0;} .hypeBtns {width:100%; background:rgba(10, 55, 125,0.5); z-index: 4; position: fixed; left: 0; bottom: 0; padding: 10px 0;} .hypeBtns a {width:46%; height:45px; position:relative; float:left; background:#FFC900; color:#253342; font-size:14px; font-weight: 700; font-family: greyMedium; text-align:center; line-height:45px; border-radius: 40px; margin: 0 2%;} .hypeBtn1 {} .footer {padding-bottom: 40px;} .hypeImg {width:100%; float:left;} .hypeImg img {width:100%; display:table; margin:0 auto; max-width: 350px;} .hypeFSection {width:100%; float:left;} .hypeBtns2 {position: relative; float: left; background: none; margin-top: 10px; margin-bottom: -10px;} footer.o-footer {clear: both; width: 100%; float: left;}';
         a+="@media only screen and (max-width: 350px) { .hypeST1 {width: 430px; font-size: 25px; letter-spacing: -0.7px;} .hypeST2 {line-height:30px;} }";a+="\x3c/style\x3e";document.head.insertAdjacentHTML("beforeend",a)}0==document.querySelectorAll(".hypeSection").length&&(a='\x3cdiv class\x3d"hypeSection"\x3e',a+='\x3cdiv class\x3d"hypeSectionTop"\x3e \x3cdiv class\x3d"hypeImg"\x3e \x3cimg src\x3d"https://cro.hype.com.tr/resimler/turkcell/teasy.jpeg"\x3e \x3c/div\x3e \x3cdiv class\x3d"hypeST1"\x3e8 GB Hediyeli Hatt\u0131n Kap\u0131na \u00dccretsiz Gelsin\x3c/div\x3e \x3cdiv class\x3d"hypeST2"\x3e\u015eimdi fatural\u0131 Turkcell\'li ol, ilk 4 ay boyunca her ay 2GB hediye internet kazan!\x3c/div\x3e\x3c/div\x3e',
         a+='\x3cdiv class\x3d"hypeSectionTop2"\x3e \x3cdiv class\x3d"hypeBar"\x3e\x3c/div\x3e \x3cdiv class\x3d"hypeOrt1"\x3e \x3cdiv class\x3d"hypeOrt2"\x3e \x3cdiv class\x3d"hypeItem"\x3e \x3cimg src\x3d"//useruploads.visualwebsiteoptimizer.com/useruploads/386793/images/ad53a50277dbdfaaee245644c12c3d8a_icon1.png"\x3e \x3cdiv class\x3d"hypeText"\x3e \x3cdiv class\x3d"hypeOrt1"\x3e \x3cdiv class\x3d"hypeOrt2"\x3e Paketini \x3cstrong\x3ese\u00e7\x3c/strong\x3e \x3c/div\x3e \x3c/div\x3e \x3c/div\x3e \x3c/div\x3e \x3c!-- hypeItem --\x3e \x3cdiv class\x3d"hypeItem"\x3e \x3cimg src\x3d"//useruploads.visualwebsiteoptimizer.com/useruploads/386793/images/f0c68a0d474b9382fd74979c94575056_icon2.png"\x3e \x3cdiv class\x3d"hypeText"\x3e \x3cdiv class\x3d"hypeOrt1"\x3e \x3cdiv class\x3d"hypeOrt2"\x3e Formu \x3cstrong\x3edoldur\x3c/strong\x3e \x3c/div\x3e \x3c/div\x3e \x3c/div\x3e \x3c/div\x3e \x3c!-- hypeItem --\x3e \x3cdiv class\x3d"hypeItem"\x3e \x3cimg src\x3d"//useruploads.visualwebsiteoptimizer.com/useruploads/386793/images/566146e58ccad1776dea626bb9be47d7_icon3.png"\x3e \x3cdiv class\x3d"hypeText"\x3e \x3cdiv class\x3d"hypeOrt1"\x3e \x3cdiv class\x3d"hypeOrt2"\x3e Diledi\u011fin yere \x3cstrong\x3ehatt\u0131n\u0131 getirelim\x3c/strong\x3e \x3c/div\x3e \x3c/div\x3e \x3c/div\x3e \x3c/div\x3e \x3c!-- hypeItem --\x3e \x3c/div\x3e \x3c/div\x3e \x3c!-- hypeOrt1 --\x3e \x3c/div\x3e \x3cdiv class\x3d"hypeBtns hypeBtns1"\x3e \x3ca href\x3d"javascript:;" class\x3d"hypeBtn1"\x3eNumara Ta\u015f\u0131ma\x3c/a\x3e \x3ca href\x3d"javascript:;" class\x3d"hypeBtn2"\x3eYeni Hat Al\x3c/a\x3e \x3c/div\x3e',
         a+='\x3cdiv class\x3d"hypeBtns hypeBtns2"\x3e \x3ca href\x3d"javascript:;" class\x3d"hypeBtn1"\x3eNumara Ta\u015f\u0131ma\x3c/a\x3e \x3ca href\x3d"javascript:;" class\x3d"hypeBtn2"\x3eYeni Hat Al\x3c/a\x3e \x3c/div\x3e',a+="\x3c/div\x3e",document.querySelector(".mnt-page[data-step\x3d'0']").insertAdjacentHTML("beforeend",a),window.dataLayer=window.dataLayer||[],window.dataLayer.push({event:"hypeBadgeMobile01"}));50<window.scrollY?0!==document.querySelectorAll(".hypeBtns").length&&(document.querySelector(".hypeBtns1").style.display=
         "none",document.querySelector(".hypeBtns2").style.display="block"):0!==document.querySelectorAll(".hypeBtns").length&&(document.querySelector(".hypeBtns1").style.display="block",document.querySelector(".hypeBtns2").style.display="none");window.onscroll=function(){50<window.scrollY?0!==document.querySelectorAll(".hypeBtns").length&&(document.querySelector(".hypeBtns1").style.display="none",document.querySelector(".hypeBtns2").style.display="block"):0!==document.querySelectorAll(".hypeBtns").length&&
         (document.querySelector(".hypeBtns1").style.display="block",document.querySelector(".hypeBtns2").style.display="none")};0!==document.querySelectorAll(".number-info-tab").length&&(document.querySelector(".hypeBtns1 .hypeBtn1").addEventListener("click",function(){document.querySelector(".mnt-page[data-step\x3d'0'] #product_buy_button").click();document.querySelectorAll(".number-info-tab")[0].click()}),document.querySelector(".hypeBtns1 .hypeBtn2").addEventListener("click",function(){document.querySelector(".mnt-page[data-step\x3d'0'] #product_buy_button").click();
         document.querySelectorAll(".number-info-tab")[1].click()}),document.querySelector(".hypeBtns2 .hypeBtn1").addEventListener("click",function(){document.querySelector(".mnt-page[data-step\x3d'0'] #product_buy_button").click();document.querySelectorAll(".number-info-tab")[0].click()}),document.querySelector(".hypeBtns2 .hypeBtn2").addEventListener("click",function(){document.querySelector(".mnt-page[data-step\x3d'0'] #product_buy_button").click();document.querySelectorAll(".number-info-tab")[1].click()}))});
      </script><script type="text/javascript" id="">hype.checkifloaded("document.querySelectorAll('._hj-f5b2a1eb-9b07_feedback_minimized_label_text').length \x3e 0",function(){var a=document.querySelector("._hj-f5b2a1eb-9b07_feedback_minimized_label_text");a.textContent="Bir sorun mu var?"});</script><script type="text/javascript" id="">document.querySelectorAll(".m-quick-nav li").forEach(function(a){a.addEventListener("click",function(b){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"GAEvent",eventCategory:"Mobil Buton Click",eventAction:"Hamburger Men\u00fc",eventLabel:this.innerText.trim()})})});</script><script type="text/javascript" id="" charset="UTF-8" src="//cdn.segmentify.com/089e370c-ecd9-4631-bee1-3fadb4ae3b34/segmentify.js"></script><script type="text/javascript" id="">window.hasOwnProperty("createCookie")&&window.createCookie("nprd",google_tag_manager["GTM-MLFT"].macro(17));</script><script type="text/javascript" id="">(function(){if("loggedin"==google_tag_manager["GTM-MLFT"].macro(18)){var b="/paket-ve-tarifeler/yeni-musteri-paketleri/gnc-gamer /paket-ve-tarifeler/4-5-g-hizinda/gnc-gamer-ben /paket-ve-tarifeler/4-5-g-hizinda/gnc-sosyallesen-ben /paket-ve-tarifeler/4-5-g-hizinda/gnc-net-ben /paket-ve-tarifeler/konusma/gnc-mega-4-gb-paketi /paket-ve-tarifeler/konusma/gnc-mega-4-gb-eko-paketi /paket-ve-tarifeler/konusma/gnc-mega-8-gb-eko-paketi /paket-ve-tarifeler/konusma/gnc-mega-8-gb-paketi /paket-ve-tarifeler/konusma/gnc-plus-6-gb-paketi /paket-ve-tarifeler/konusma/gnc-mega-12-gb-paketi /paket-ve-tarifeler/konusma/gnc-mega-12-gb-eko-paketi /paket-ve-tarifeler/konusma/super-bol-20-gb /paket-ve-tarifeler/konusma/gnc-plus-7-gb-paketi /paket-ve-tarifeler/konusma/gnc-mega-16-gb-paketi /paket-ve-tarifeler/konusma/gnc-mega-16-gb-eko-paketi /paket-ve-tarifeler/konusma/gnc-plus-9-gb-paketi".split(" ");
         b.includes(window.location.pathname)&&(b='document.querySelectorAll("h1.title").length \x3e 0 || document.querySelectorAll("#main_container").length \x3e 0',hype.checkifloaded(b,function(){var a="hype-hello-bar-style";document.querySelector("#"+a)||(a='\x3cstyle id\x3d"'+a+'"\x3e\n          .h-hello-bar {\n            text-align: center;\n            font-weight: bold;\n            background: #ffd917;\n            color: #2855ac;\n            padding: 5px;\n          }\n          .h-hello-bar p {\n            font-size: 13px; font-family: GreycliffCF,Helvetica,Calibri,sans-serif;\n            margin: 0px;\n          }\n          @media (min-width: 768px) {\n            .h-hello-bar p {\n              font-size: 14px;\n            }\n          }\n        \x3c/style\x3e',
         document.head.insertAdjacentHTML("beforeend",a));a='\x3cdiv class\x3d"h-hello-bar"\x3e\n      \x3cp\x3e\n        Paket de\u011fi\u015fiminde cayma \u00fccreti yans\u0131maz. Paket haklar\u0131n\u0131 ve i\u00e7eriklerini kullanmaya paket\n        de\u011fi\u015fiminden sonra gelen SMS\u2019in ard\u0131ndan hemen ba\u015flayabilirsiniz.\n      \x3c/p\x3e\n    \x3c/div\x3e';var c=document.querySelector(hype.isMobile()?"h1.title":"#main_container");c.insertAdjacentHTML(hype.isMobile()?"beforebegin":
         "afterbegin",a)}))}})();
      </script><script type="text/javascript" id="">hype.isMobile()?hype.checkifloaded("document.querySelectorAll('#product-list-cards').length \x3e 0",function(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"hypeCategoryCountdownEvent"})}):hype.checkifloaded("document.querySelectorAll('h1.product-list__title').length \x3e 0",function(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"hypeCategoryCountdownEvent"})});</script><script type="text/javascript" id="">(function(){function a(c){0>c.clientY&&(window.dataLayer=window.dataLayer||[],window.dataLayer.push({event:"hypeExitIntentPopupEvent"}),document.removeEventListener("mouseleave",a))}var b=1E3;/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)?setTimeout(function(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"hypeExitIntentPopupEvent"})},10*b):setTimeout(function(){document.addEventListener("mouseleave",a)},3*b)})();</script><script type="text/javascript" id="">if("/kampanyalar/ev-interneti-fiber-kampanyalari/1000-mbps-fiber-firsat-kampanyasi"==location.pathname){var button=document.querySelector("a.but.but--primary.has-hover-icon.text-satura.text-truncate.marv")||document.querySelector(".btn.button-cta.satinal-btn");button.addEventListener("click",function(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"GAEvent",eventCategory:"AB Test",eventAction:"Dijitale \u00d6zel Ba\u015fvur Buton Click",eventLabel:location.pathname})})}else"/kampanyalar/form/1000-mbps-fiber-firsat-kampanyasi"==
         location.pathname&&(button=document.querySelector("#sol-campaign-form-submit-button"),button.addEventListener("click",function(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"GAEvent",eventCategory:"AB Test",eventAction:"Dijitale \u00d6zel Ba\u015fvur Buton Click",eventLabel:location.pathname})}));
      </script><script type="text/javascript" id="">localStorage.getItem("16_20_OCAK_BU_MU_BU_MU")||(window.dataLayer=window.dataLayer||[],window.dataLayer.push({event:"START_16_20_OCAK_BU_MU_BU_MU"}));</script><script type="text/javascript" id="">1==window.hasOwnProperty("utag_data")&&("undefined"!=typeof utag_data["js_page.cust.customer_id"]&&dataLayer.push({customerId:utag_data["js_page.cust.customer_id"],customerDevice:utag_data["js_page.cust.Cus_device_brand"]+" | "+utag_data["js_page.cust.Cus_device_model"],customerPackage:utag_data["js_page.cust.customer_package"],customerPaymentType:utag_data["js_page.cust.payment_type"],customerSkStatus:utag_data["js_page.cust.customer_sk_status"],customerSegment:utag_data["js_page.cust.customer_segment_ALTS"]}),
         dataLayer.push({event:"crmLoaded"}));
      </script><script type="text/javascript" id="">!function(d,e,f,g,h,k,a,b,c){d[g]||(a=d[g]=function(){"function"===typeof a.execute?a.execute.apply(a,arguments):a.queue.push(arguments)},a.version="1.0",a.queue=[],b=e.createElement(f),b.async=!0,a.svc=h,b.src=h+k,c=e.getElementsByTagName(f)[0],c.parentNode.insertBefore(b,c))}(window,document,"script","advermind","https://signals.turkcell.com.tr","/base.js");advermind("init","470016443928963");advermind("track","PageView");</script>
      <script type="text/javascript" id="">try{var expcookie="GAX1.3.bdyrD5NlRyOt23sB1PK_2g.19141.1";if(""!==expcookie&&"undefined"!==expcookie){var expid=expcookie.match(/\..\.(.*?)\.[0-9][0-9][0-9]*/)[1],expvar=expcookie.match(/\.([0-9][0-9]?!?$)/)[1];window.hj=window.hj||function(){(hj.q=hj.q||[]).push(arguments)};hj("tagRecording",["Experiment",expid+" - "+expvar])}}catch(a){console.log(a)};</script>
      <script type="text/javascript" id="">$(document).ready(function(){$("section a,section .a-btn-icon,section button,section canvas").click(function(a){var e=$(this);a=["m-slider_prev","m-slider_next","m-card--product"];var f=!0;$.each(a,function(k,g){e.hasClass(g)&&(f=!1)});if(1==f){var d=$(this).closest("section"),b=$(this).closest(".m-carousel div[id*\x3d'banner-']");a=null;0!==d.length&&(a=d);0!==b.length&&(a=b);if(0!==a.length&&void 0!==a.attr("data-ga-id")){d=a.attr("data-ga-id");b=a.attr("data-ga-name");var c=a.attr("data-ga-creative"),
         h=a.attr("data-ga-position");a=a.attr("data-ga-event-label");void 0!==$(this).attr("data-desc")?a=a+" - "+$(this).attr("data-desc"):void 0!==$(this).attr("title")?a=a+" - "+$(this).attr("title"):void 0!==$(this).attr("href")&&(a=a+" - "+$(this).attr("href"));if("component-passage_stories"==b||"component-passage_campaign_list"==b||"component-passage_opportunity_list"==b)c=e.find("img").attr("src").split("/"),c=c[c.length-1],c=c.split(".")[0];dataLayer=dataLayer||[];dataLayer.push({event:"ecInternalPromotionClick",
         eventCategory:"Internal Promotions",eventAction:"Promotion Click",eventLabel:a,ecommerce:{promoClick:{promotions:[{id:d,name:b,creative:c,position:h}]}}})}}})});
      </script><script type="text/javascript" id="">$(document).ready(function(){window.ga_promo_view_array=[];window.ga_swiper_view_array=[];hype=hype||{};"/"==location.pathname&&hype.checkifloaded("document.querySelector('main .swiper-container') !\x3d\x3d null",function(){var e=document.querySelector("main .swiper-container").swiper,l=e.slides.length-2,f=0,h=function(a){g($(".m-carousel .swiper-slide-next"))},g=function(a){if(void 0!==a.attr("data-ga-id")){var d=null,c=null,b=null,k=null;void 0!==a.attr("data-ga-id")&&(d=a.attr("data-ga-id"));void 0!==
         a.attr("data-ga-name")&&(c=a.attr("data-ga-name"));if("component-passage_stories"==c||"component-passage_campaign_list"==c||"component-passage_opportunity_list"==c)b=t.find("img").attr("src").split("/"),b=b[b.length-1],b=b.split(".")[0];void 0!==a.attr("data-ga-creative")&&(b=a.attr("data-ga-creative"));void 0!==a.attr("data-ga-position")&&(k=a.attr("data-ga-position"));-1==ga_swiper_view_array.indexOf(d)?(dataLayer=dataLayer||[],dataLayer.push({event:"ecInternalPromotionView",eventCategory:"Internal Promotions",
         eventAction:"Promotion View",eventLabel:"",ecommerce:{promoView:{promotions:[{id:d,name:c,creative:b,position:k}]}}}),ga_swiper_view_array.push(d)):(f++,f==l&&e.off("slideChange",h))}};g($(".m-carousel .swiper-slide-active"));e.on("slideChange",h)})});
      </script><script type="text/javascript" id="">0!==document.querySelectorAll(".m-dashboard__phone").length&&document.querySelector(".m-dashboard__phone").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".media__body").length&&document.querySelector(".media__body").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".otp-msisdn").length&&document.querySelector(".otp-msisdn").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#avatar-thumb-holder .member").length&&document.querySelector("#avatar-thumb-holder .member").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".m-user-profile img").length&&document.querySelector(".m-user-profile img").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#profilePicLink .media__image").length&&document.querySelector("#profilePicLink .media__image").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#user_profile_photo .media__body-wrap h3").length&&document.querySelector("#user_profile_photo .media__body-wrap h3").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#header-mobile-search h2").length&&document.querySelector("#header-mobile-search h2").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .nameSurname").length&&document.querySelector("#general-six .nameSurname").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#general-six .msisdn").length&&document.querySelector("#general-six .msisdn").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .address").length&&document.querySelector("#general-six .address").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .addressBilling").length&&document.querySelector("#general-six .addressBilling").setAttribute("data-hj-suppress","");
      </script><script type="text/javascript" id="">0!==document.querySelectorAll(".m-dashboard__phone").length&&document.querySelector(".m-dashboard__phone").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".media__body").length&&document.querySelector(".media__body").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".otp-msisdn").length&&document.querySelector(".otp-msisdn").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#avatar-thumb-holder .member").length&&document.querySelector("#avatar-thumb-holder .member").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".m-user-profile img").length&&document.querySelector(".m-user-profile img").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#profilePicLink .media__image").length&&document.querySelector("#profilePicLink .media__image").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#user_profile_photo .media__body-wrap h3").length&&document.querySelector("#user_profile_photo .media__body-wrap h3").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#header-mobile-search h2").length&&document.querySelector("#header-mobile-search h2").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .nameSurname").length&&document.querySelector("#general-six .nameSurname").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#general-six .msisdn").length&&document.querySelector("#general-six .msisdn").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .address").length&&document.querySelector("#general-six .address").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .addressBilling").length&&document.querySelector("#general-six .addressBilling").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll(".disabledTextbox").length&&document.querySelector(".disabledTextbox").setAttribute("data-hj-suppress","");
      </script>
      <script type="text/javascript" id="" src="https://www.googletagmanager.com/gtag/js?id=DC-10138642"></script><script type="text/javascript" id="">var prElement=document.querySelector('meta[name\x3d"mainCategory"]'),cx_category=prElement&&prElement.getAttribute("content");!function(b,c,d,a){b.mpfContainr||(b.mpfContainr=function(){d.push(arguments)},mpfContainr.q=d,(a=c.createElement("script")).type="application/javascript",a.async=!0,a.src="//cdn.mookie1.com/containr.js",c.head.appendChild(a))}(window,document,[]);
         mpfContainr("V2_872264",{host:"tr-gmtdmp.mookie1.com",tagType:"activity","src.rand":utag_data.timestamp,"src.category-name":cx_category,"src.sales-order-id":utag_data.order_id,"src.basket":utag_data.basket,"src.price":utag_data.tiklaalrev||utag_data.order_total,"src.product-name":utag_data.gsm_product_name||utag_data.product_name,"src.home-page":utag_data.homepage,"src.product-id":utag_data.product_id,"src.sales":utag_data.sales});
      </script>
      <noscript>
         <iframe src="//tr-gmtdmp.mookie1.com/t/v2?tagid=V2_872264&amp;isNoScript&amp;src.category-name=[REPLACE THIS WITH YOUR MACRO AND PASS IN Category]&amp;src.sales-order-id=[REPLACE THIS WITH YOUR MACRO AND PASS IN Sales ID / Order ID]&amp;src.basket=[REPLACE THIS WITH YOUR MACRO AND PASS IN Basket]&amp;src.price=[REPLACE THIS WITH YOUR MACRO AND PASS IN Price]&amp;src.product-name=[REPLACE THIS WITH YOUR MACRO AND PASS IN Product Name]&amp;src.home-page=[REPLACE THIS WITH YOUR MACRO AND PASS IN Home Page]&amp;src.product-id=[REPLACE THIS WITH YOUR MACRO AND PASS IN Product ID]&amp;src.sales=[REPLACE THIS WITH YOUR MACRO AND PASS IN Sales]&amp;src.rand=[timestamp]" height="0" width="0" style="display:none;visibility:hidden"></iframe>
      </noscript>
      <script type="text/javascript" id="">var now=new Date,eventTime=now.getDay()+"/"+Number(now.getMonth()+1)+"/"+now.getFullYear()+"-"+now.getHours()+":"+now.getMinutes()+":"+now.getSeconds();utag_data.timestamp=eventTime;</script><script type="text/javascript" id="" src="//turkcell.api.useinsider.com/ins.js?id=10000432"></script>
      <script type="text/javascript" id="" src="https://www.googletagmanager.com/gtag/js?id=DC-10978247"></script>
      <script type="text/javascript" id="" src="https://www.googletagmanager.com/gtag/js?id=DC-11603480"></script>
      <script type="text/javascript" id="" src="https://www.googletagmanager.com/gtag/js?id=DC-10978658"></script><script type="text/javascript" id="">var hjtags=[],replaceValues=function(b){viki=b;switch(b){case "logged_in":viki="Logged-In";break;case "not_logged_in":viki="Not Logged-In"}return viki},dynhjtag=function(b,a){""!==a&&"undefined"!==a&&"null"!==a&&(a=replaceValues(a),hjtags.push(b+": "+a))};dynhjtag("Customer Type","undefined");dynhjtag("Login Status","undefined");dynhjtag("Package","undefined");dynhjtag("Tariff","undefined");window.hj=window.hj||function(){(window.hj.q=window.hj.q||[]).push(arguments)};
         window.hj("tagRecording",hjtags);
      </script>
      <script type="text/javascript" id="">window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag("js",new Date);gtag("config","DC-10138642");</script>
      <iframe height="0" width="0" style="display: none; visibility: hidden;" src="https://10138642.fls.doubleclick.net/activityi;src=10138642;type=invmedia;cat=turkc0;ord=7714527899386;gtm=2od2n0;auiddc=952129103.1645804765;u1=null;u2=undefined;u3=undefined;u4=undefined;u5=undefined;u6=undefined;u7=undefined;u8=undefined;~oref=http%3A%2F%2Flocalhost%2Fturkcellhattasima%2F?"></iframe><script type="text/javascript" id="">var prElement=document.querySelector('meta[name\x3d"mainCategory"]'),cx_category=prElement&&prElement.getAttribute("content");gtag("event","conversion",{allow_custom_scripts:!0,u1:cx_category,u2:utag_data.order_id,u3:utag_data.basket,u4:utag_data.tiklaalrev||utag_data.order_total,u5:utag_data.gsm_product_name||utag_data.product_name,u6:utag_data.homepage,u7:utag_data.product_id,u8:utag_data.sales,send_to:"DC-10138642/invmedia/turkc0+standard"});</script>
      <noscript>
         <img src="https://ad.doubleclick.net/ddm/activity/src=10138642;type=invmedia;cat=turkc0;u1=[CATEGORY-NAME];u2=[SALES ID / ORDER ID];u3=[BASKET];u4=[PRICE];u5=[PRODUCT-NAME];u6=[HOME-PAGE];u7=[PRODUCT-ID];u8=[SALES];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;tfua=;npa=;ord=1?" width="1" height="1" alt="">
      </noscript>
      <iframe height="0" width="0" style="display: none; visibility: hidden;" src="https://10138642.fls.doubleclick.net/activityi;src=10138642;type=invmedia;cat=turkc0;ord=9990316066962;gtm=2od2n0;auiddc=1597952008.1643138476;u1=null;u2=undefined;u3=undefined;u4=undefined;u5=undefined;u6=undefined;u7=undefined;u8=undefined;~oref=https%3A%2F%2Fm.turkcell.com.tr%2Ftr%2Fturkcellli-olmak%2Fnumara-secimi?"></iframe><iframe name="_hjRemoteVarsFrame" title="_hjRemoteVarsFrame" id="_hjRemoteVarsFrame" src="https://vars.hotjar.com/box-acca23410e696f2ca3087d947271c3d0.html" style="display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;"></iframe><iframe name="_hjRemoteVarsFrame" title="_hjRemoteVarsFrame" id="_hjRemoteVarsFrame" src="https://vars.hotjar.com/box-acca23410e696f2ca3087d947271c3d0.html" style="display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;"></iframe><script type="text/javascript" id="">var hjtags=[],replaceValues=function(b){viki=b;switch(b){case "logged_in":viki="Logged-In";break;case "not_logged_in":viki="Not Logged-In"}return viki},dynhjtag=function(b,a){""!==a&&"undefined"!==a&&"null"!==a&&(a=replaceValues(a),hjtags.push(b+": "+a))};dynhjtag("Customer Type","undefined");dynhjtag("Login Status","undefined");dynhjtag("Package","undefined");dynhjtag("Tariff","undefined");window.hj=window.hj||function(){(window.hj.q=window.hj.q||[]).push(arguments)};
         window.hj("tagRecording",hjtags);
      </script><script type="text/javascript" id="">hype={pagedata:{},logger:{groupOpened:!1},modal:{},exitIntent:{},create:{},hyperootdomain:window.location.host,listenedFunctions:{},lastListenedEvent:null,dataLayerIndex:-1,dataLayerEcIndex:-1,loggerstarted:!1,what:Object.prototype.toString,asciilogo:"  _                      \n | |                     \n | |__  _   _ _ __   ___ \n | '_ \\| | | | '_ \\ / _ \\\n | | | | |_| | |_) |  __/\n |_| |_|\\__, | .__/ \\___|\n         __/ | |         \n        |___/|_|         ",isObjectEmpty:function(a){for(var b in a)if(Object.prototype.hasOwnProperty.call(a,
         b))return!1;return!0},isMobile:function(){return/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,
         4))?!0:!1}};window.hype.getDataLayerVariable=function(a){var b=null;if(1==window.hasOwnProperty("dataLayer"))for(var c=0,d=window.dataLayer.length;c<d;c++)1==window.dataLayer[c].hasOwnProperty(a)&&(b=window.dataLayer[c][a]);return b};hype.logger.isActive=function(){if(Storage)return!0===localStorage.getItem("hypeLogger")?!0:!1};hype.logger.activate=function(){Storage&&(localStorage.setItem("hypeLogger",!0),confirm("Hype logger aktifle\u015ftirildi, sayfay\u0131 yenileyim mi?")&&location.reload())};
         hype.logger.stop=function(){Storage&&(localStorage.setItem("hypeLogger",!1),confirm("Hype logger kapat\u0131ld\u0131, sayfay\u0131 yenileyim mi?")&&location.reload())};hype.logger.info=function(a){"true"==localStorage.getItem("hypeLogger")&&(!1===hype.loggerstarted&&(console.log(hype.asciilogo),hype.loggerstarted=!0),console.info("[HYPE Bilgi]: "+a))};
         hype.waitForSelectors=function(a,b,c){var d,e;b||(b=0);c||(c=3E4);return new Promise(function(g,f){d=setInterval(function(){var h=a.map(function(k){return document.querySelector(k)}).every(Boolean);if(h)return clearInterval(d),clearTimeout(e),g()},b);e=setTimeout(function(){clearInterval(d);return f("Element not found")},c)})};
         hype.logger.warn=function(a){"true"==localStorage.getItem("hypeLogger")&&(!1===hype.loggerstarted&&(console.log(hype.asciilogo),hype.loggerstarted=!0),console.warn("[HYPE Uyar\u0131]: "+a))};hype.logger.group=function(){"true"==localStorage.getItem("hypeLogger")&&!1===hype.logger.groupOpened&&(console.group(),hype.logger.groupOpened=!0)};hype.logger.groupEnd=function(){"true"==localStorage.getItem("hypeLogger")&&(console.groupEnd(),hype.logger.groupOpened=!1)};
         window.hype.checkifloaded=function(a,b,c,d,e){var g=!1;"undefined"==typeof window.hype.checkerSlot&&(window.hype.checkerSlot=[]);var f=window.hype.checkerSlot;"number"!==typeof e&&(e=f.length,f[f.length]=0);var h=c||100,k=d||50;setTimeout(function(){!1===window.eval(a)&&f[e]<1E3*k/h&&!1===g?(hype.logger.info(a+" ifadesi true d\u00f6nmedi, "+c+"ms bekliyorum."),f[e]++,window.hype.checkifloaded(a,b,h,k,e)):f[e]>=1E3*k/h?hype.logger.warn("s\u00fcre doldu ne yazik ki bulamadik"):(hype.logger.info("ifade "+
         50*(f[e]+1)/1E3+" saniyede bulundu, fonksiyonu calistiriyorum"),g=!0,b())},h)};hype.setCookie=function(a,b,c){var d=new Date;d.setTime(d.getTime()+864E5*c);d="expires\x3d"+d.toUTCString();document.cookie=0==c?a+"\x3d"+b+"; domain\x3d."+hype.hyperootdomain+";path\x3d/":a+"\x3d"+b+"; "+d+"; domain\x3d."+hype.hyperootdomain+";path\x3d/"};
         hype.getCookie=function(a){a+="\x3d";for(var b=document.cookie.split(";"),c=0;c<b.length;c++){for(var d=b[c];" "==d.charAt(0);)d=d.substring(1);if(0==d.indexOf(a))return d.substring(a.length,d.length)}return""};hype.checkCookie=function(a){return""!=hype.getCookie(a)?!0:!1};hype.removeCookie=function(a){var b="expires\x3dThu, 01 Jan 1970 00:00:00 UTC;";document.cookie=a+"\x3d; "+b+"domain\x3d."+hype.hyperootdomain+";path\x3d/";document.cookie=a+"\x3d; "+b+"path\x3d/";document.cookie=a+"\x3d; "+b};
         hype.toFixed=function(a,b){b=b||0;var c=Math.pow(10,b),d=Math.abs(Math.round(a*c));a=(0>a?"-":"")+String(Math.floor(d/c));0<b&&(c=String(d%c),b=Array(Math.max(b-c.length,0)+1).join("0"),a+="."+b+c);return a};
         window.hype.dateIsBetween=function(a,b,c){if("undefined"==typeof a)return!1;var d=/(\d{2})\-(\d{2})-(\d{4})/;b="function"===typeof b.getMonth?b:new Date(b.replace(d,"$3-$2-$1"));var e="function"===typeof c.getMonth?c:new Date(c.replace(d,"$3-$2-$1"));a="function"===typeof a.getMonth?c:new Date(a.replace(d,"$3-$2-$1"));return a<e&&a>b||a.getTime()==b.getTime()&&b.getTime()==e.getTime()?!0:!1};
         hype.modal=function(a){void 0==a&&(a={});var b=a.className||"",c=a.idName||"",d=a.width||"50vw",e=a.height||"500px",g=a.left||"calc(50% - 25vw)",f=a.right||"auto",h=a.top||"calc(50% - 250px)",k=a.bottom||"auto",p=a.background||"#fff",q=a.padding||"25px",m=a.position||"fixed",n=a.display||"block",r=a.closeImg||"https://hypeistanbul.com/img/close.jpg";a=a.html||"";var l='\x3cstyle class\x3d"hypeModalStyle"\x3e';l+=".hypeModal {width:"+d+"; height:"+e+"; left:"+g+"; right:"+f+"; top:"+h+"; bottom:"+
         k+"; background:"+p+"; padding:"+q+"; position:"+m+"; z-index: 9999; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; display:"+n+";} .hypeModalBlocker {width:100%; height:100vh; position:"+m+"; left:0; top:0; z-index: 9990; background:rgba(0,0,0,0.7);  display:"+n+";} .hypeClose {width:40px; height:40px; position:absolute; right:-20px; top:-20px; background:url("+r+") no-repeat center center; background-size:100%;}";l+="\x3c/style\x3e";document.head.insertAdjacentHTML("beforeend",
         l);b='\x3cdiv class\x3d"hypeModal '+b+'" id\x3d"'+c+'"\x3e \x3ca href\x3d"javascript:;" class\x3d"hypeClose"\x3e\x3c/a\x3e \x3cdiv class\x3d"hypeModalContent"\x3e '+a+" \x3c/div\x3e  \x3c/div\x3e";document.querySelector("body").insertAdjacentHTML("beforeend",b);0==document.querySelectorAll(".hypeModalBlocker").length?(b='\x3cdiv class\x3d"hypeModalBlocker"\x3e \x3c/div\x3e',document.querySelector("body").insertAdjacentHTML("beforeend",b)):document.querySelector(".hypeModalBlocker").style.display=
         "block";if(0!==document.querySelectorAll(".hypeClose").length)for(b=0;b<document.querySelectorAll(".hypeClose").length;b++)document.querySelectorAll(".hypeClose")[b].addEventListener("click",function(){hype.modal.hide()});if(0!==document.querySelectorAll(".hypeModalBlocker").length)for(b=0;b<document.querySelectorAll(".hypeModalBlocker").length;b++)document.querySelectorAll(".hypeModalBlocker")[b].addEventListener("click",function(){hype.modal.hide()})};
         hype.modal.hide=function(a){a=a||".hypeModal";var b=document.querySelectorAll(a).length;0!==document.querySelectorAll(".hypeModalBlocker").length&&(document.querySelector(".hypeModalBlocker").style.display="none");for(var c=0;c<b;c++)0!==document.querySelectorAll(a).length&&(document.querySelectorAll(a)[c].style.display="none")};
         hype.modal.show=function(a){a=a||".hypeModal";var b=document.querySelectorAll(a).length;0!==document.querySelectorAll(".hypeModalBlocker").length&&(document.querySelector(".hypeModalBlocker").style.display="block");for(var c=0;c<b;c++)0!==document.querySelectorAll(a).length&&(document.querySelectorAll(a)[c].style.display="block")};
         hype.exitIntent=function(a,b){void 0==a&&(a={});var c=a.cookie||"1";"function"!==typeof b&&(b=function(){hype.logger.warn("Herhangi bir fonksiyon yaz\u0131lmas\u0131 laz\u0131m!")});document.addEventListener("mouseleave",function(d){0>d.clientY&&("1"==c?!0!==hype.checkCookie("hype-exit")&&(hype.setCookie("hype-exit",!0),cookieStatus=!1,b()):b())},!1);document.querySelector(".blutv-logo")&&document.querySelector(".blutv-logo").addEventListener("mouseenter",function(d){0>d.clientY&&("1"==c?!0!==hype.checkCookie("hype-exit")&&
         (hype.setCookie("hype-exit",!0),cookieStatus=!1,b()):b())},!1)};hype.insertAfter=function(a,b){b.parentNode.insertBefore(a,b.nextSibling)};hype.insertBefore=function(a,b){b.parentNode.insertBefore(a,b)};hype.append=function(a){void 0==a&&(a={});var b=a.selectorName||"body",c=a.position||"beforeend";html=a.html||"";document.querySelector(b).insertAdjacentHTML(c,html)};hype.click=function(a,b){document.querySelectorAll(a).forEach(function(c){console.log(c);c.addEventListener("click",b)})};
         hype.focus=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("focus",b)})};hype.blur=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("blur",b)})};hype.change=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("change",b)})};hype.keyup=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("keyup",b)})};
         hype.keypress=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("keypress",b)})};hype.keydown=function(a,b){document.querySelectorAll(a).forEach(function(c){c.addEventListener("keydown",b)})};hype.selectAll=function(a){return document.querySelectorAll(a)};hype.select=function(a){return document.querySelector(a)};hype.screenwidth=function(){var a=window,b=document,c=b.documentElement;b=b.getElementsByTagName("body")[0];return a=a.innerWidth||c.clientWidth||b.clientWidth};
         hype.ajaxget=function(a,b){var c=new XMLHttpRequest;c.open("GET",a,!0);c.send();c.onreadystatechange=function(){4==this.readyState&&200==this.status&&b(this.responseText)}};hype.ajaxpost=function(a,b,c,d){c=new XMLHttpRequest;c.open("POST",a,!0);c.setRequestHeader("Content-type","application/x-www-form-urlencoded");c.send(b);c.onreadystatechange=function(){4==this.readyState&&200==this.status&&d(this.responseText)}};
         hype.sendAnalyticsData=function(a,b,c){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"hypeEvent",eventCategory:a,eventAction:b,eventLabel:c})};window.hype.hypeListenedInputs=[];window.hype.hypeListenedInputsEmpty=[];
         window.hype.hypeInputAnalyzer=function(a,b,c){var d="",e=hype.select(a+" "+b);if(null!==e){var g=function(){-1==hype.hypeListenedInputs.indexOf(a+" "+b)?(hype.hypeListenedInputs.push(a+" "+b),hype.hypeListenedInputs[0]==a+" "+b?hype.sendAnalyticsData("Micro Funnel",c,d+" - Dolu Ge\u00e7ti - \u0130lk Bunu Doldurdu"):hype.sendAnalyticsData("Micro Funnel",c,d+" - Dolu Ge\u00e7ti")):hype.sendAnalyticsData("Micro Funnel",c,d+" - Tekrar Doldurdu")};if("SELECT"==e.tagName)e.attributes.hasOwnProperty("placeholder")&&
         (d=e.attributes.placeholder.value),"#country_code"===b&&(d="\u00dclke Se\u00e7iniz"),"#expireMonth"===b&&(d="Ay"),"#expireYear"===b&&(d="Y\u0131l"),window.hype.blur(b,function(f){window.setTimeout(function(){""!==f.target.value&&g()},200)});else if("INPUT"==e.tagName||"TEXTAREA"==e.tagName)e.attributes.hasOwnProperty("placeholder")&&(d=e.attributes.placeholder.value),null!==b.match(/.*indirimkuponu$/)&&(d="\u0130ndirim Kuponu"),null!==b.match(/.*mobile_phone$/)&&(d="Cep Telefonu"),"#memberForm"===
         a&&"checkbox"===e.type&&(d=e.nextElementSibling.nextElementSibling.innerText),window.hype.change(b,function(f){g()});window.hype.blur(b,function(f){-1==window.hype.hypeListenedInputsEmpty.indexOf(b)&&""==this.value&&(hype.sendAnalyticsData("Micro Funnel",c,d+" - Bo\u015f Ge\u00e7ti"),hype.hypeListenedInputsEmpty.push(b))})}};
      </script><script type="text/javascript" id="">function createCookie(b,d,c){if(c){var a=new Date;a.setTime(a.getTime()+864E5*c);c="; expires\x3d"+a.toGMTString()}else c="";document.cookie=b+"\x3d"+d+c+"; path\x3d/"}function createCookieObject(){var b={},d=document.cookie;d=d.split("; ");for(var c=0;c<d.length;c++){var a=d[c].split("\x3d");if("undefined"===typeof b[a[0]])b[a[0]]=a[1];else if("string"===typeof b[a[0]]){var e=[b[a[0]],a[1]];b[a[0]]=e}else b[a[0]].push(a[1])}return b}
         function createQueryObject(){var b={},d=window.location.search.substring(1);d=d.split("\x26");for(var c=0;c<d.length;c++){var a=d[c].split("\x3d");if("undefined"===typeof b[a[0]])b[a[0]]=a[1];else if("string"===typeof b[a[0]]){var e=[b[a[0]],a[1]];b[a[0]]=e}else b[a[0]].push(a[1])}return b};
      </script>
      <script type="text/javascript" id="">var existingChannels="",existingSources="",landingPage=!1,currentChannel="",currentSource="",MC_cookies=document.cookie,cookieCharLimit=4096;
         if(-1==MC_cookies.indexOf("MC_landing")||-1!=document.URL.indexOf("utm_source")||-1!=document.referrer.indexOf("google.com")||-1!=document.referrer.indexOf("yandex.com")||30<document.referrer.indexOf("turkcell.com.tr")||-1==document.referrer.indexOf("turkcell.com.tr")){createCookie("MC_landing",1);landingPage=!0;var CookieString=createCookieObject(),QueryString=createQueryObject();"undefined"===typeof QueryString.utm_source?""===document.referrer?currentSource=currentChannel="(direct)":-1!=document.referrer.indexOf("google.com")?
         (currentChannel="Organic",currentSource="Google"):-1!=document.referrer.indexOf("yandex.com")?(currentChannel="Organic",currentSource="Yandex"):currentChannel=document.referrer.match(/:\/\/(.[^/]+)/)[1]:(currentSource=QueryString.utm_source+"/"+QueryString.utm_medium+"/"+QueryString.utm_campaign+"/"+QueryString.utm_content,currentChannel=QueryString.utm_source);"undefined"!=typeof CookieString.mcfChannels&&(4096<CookieString.mcfSourceDetails.length&&(CookieString.mcfSourceDetails=CookieString.mcfSourceDetails.substring(CookieString.mcfSourceDetails.indexOf("\x3e")+
         1,CookieString.mcfSourceDetails.length),CookieString.mcfChannels=CookieString.mcfChannels.substring(CookieString.mcfChannels.indexOf("\x3e")+1,CookieString.mcfChannels.length)),existingChannels=CookieString.mcfChannels,existingSources=CookieString.mcfSourceDetails);existingSources.substring(existingSources.lastIndexOf("\x3e")+1,existingSources.length)!=currentSource&&(0<existingSources.length&&(existingChannels+="\x3e",existingSources+="\x3e"),createCookie("mcfChannels",existingChannels+currentChannel,
         180),createCookie("mcfSourceDetails",existingSources+currentSource,180),createCookie("mcfLastInteraction",currentChannel+" | "+currentSource,180));""==existingChannels&&createCookie("mcfFirstInteraction",currentChannel+" | "+currentSource,180)};
      </script><script type="text/javascript" id="">try{document.addEventListener("click",function(a){if(-1<a.target.className.indexOf("_radio_checkbox_text")&&-1<a.target.className.indexOf("_hj")){var b=document.querySelector("[class*\x3dquestion_text]").innerText.trim(),c=a.target.innerText.trim();a=null!==a.target.parentNode.parentNode.parentNode.id.match(/_(.)$/)?a.target.parentNode.parentNode.parentNode.id.match(/_(.)$/)[1]:1;null!==document.cookie.match(/_hjDonePolls=(.*?);/)&&document.cookie.match(/_hjDonePolls=(.*?);/);a=document.querySelector("[id*\x3dquestion_text_"+
         a+"]").innerText;window.hj=window.hj||function(){(hj.q=hj.q||[]).push(arguments)};hj("ready",function(){hj("tagRecording",["Anket - "+b])});window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"GAEvent",eventCategory:"Hotjar Poll",eventAction:b,eventLabel:a+" -\x3e "+c,ecoption:"false"})}},!1)}catch(a){console.log(a)};
      </script><script type="text/javascript" id="">window.hype.checkifloaded('document.querySelectorAll(".m-cookie .js-close-cookie").length !\x3d\x3d 0',function(){document.querySelector(".m-cookie .js-close-cookie").setAttribute("href","javascript:;")},100,5);</script><script type="text/javascript" id="">hype.checkifloaded("document.querySelectorAll('._hj-f5b2a1eb-9b07_feedback_minimized_label_text').length \x3e 0",function(){var a=document.querySelector("._hj-f5b2a1eb-9b07_feedback_minimized_label_text");a.textContent="Bir sorun mu var?"});</script><script type="text/javascript" id="">document.querySelectorAll(".m-quick-nav li").forEach(function(a){a.addEventListener("click",function(b){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"GAEvent",eventCategory:"Mobil Buton Click",eventAction:"Hamburger Men\u00fc",eventLabel:this.innerText.trim()})})});</script><script type="text/javascript" id="" charset="UTF-8" src="//cdn.segmentify.com/089e370c-ecd9-4631-bee1-3fadb4ae3b34/segmentify.js"></script><script type="text/javascript" id="">window.hasOwnProperty("createCookie")&&window.createCookie("nprd",google_tag_manager["GTM-MLFT"].macro(20));</script><script type="text/javascript" id="">(function(){if("loggedin"==google_tag_manager["GTM-MLFT"].macro(21)){var b="/paket-ve-tarifeler/yeni-musteri-paketleri/gnc-gamer /paket-ve-tarifeler/4-5-g-hizinda/gnc-gamer-ben /paket-ve-tarifeler/4-5-g-hizinda/gnc-sosyallesen-ben /paket-ve-tarifeler/4-5-g-hizinda/gnc-net-ben /paket-ve-tarifeler/konusma/gnc-mega-4-gb-paketi /paket-ve-tarifeler/konusma/gnc-mega-4-gb-eko-paketi /paket-ve-tarifeler/konusma/gnc-mega-8-gb-eko-paketi /paket-ve-tarifeler/konusma/gnc-mega-8-gb-paketi /paket-ve-tarifeler/konusma/gnc-plus-6-gb-paketi /paket-ve-tarifeler/konusma/gnc-mega-12-gb-paketi /paket-ve-tarifeler/konusma/gnc-mega-12-gb-eko-paketi /paket-ve-tarifeler/konusma/super-bol-20-gb /paket-ve-tarifeler/konusma/gnc-plus-7-gb-paketi /paket-ve-tarifeler/konusma/gnc-mega-16-gb-paketi /paket-ve-tarifeler/konusma/gnc-mega-16-gb-eko-paketi /paket-ve-tarifeler/konusma/gnc-plus-9-gb-paketi".split(" ");
         b.includes(window.location.pathname)&&(b='document.querySelectorAll("h1.title").length \x3e 0 || document.querySelectorAll("#main_container").length \x3e 0',hype.checkifloaded(b,function(){var a="hype-hello-bar-style";document.querySelector("#"+a)||(a='\x3cstyle id\x3d"'+a+'"\x3e\n          .h-hello-bar {\n            text-align: center;\n            font-weight: bold;\n            background: #ffd917;\n            color: #2855ac;\n            padding: 5px;\n          }\n          .h-hello-bar p {\n            font-size: 13px; font-family: GreycliffCF,Helvetica,Calibri,sans-serif;\n            margin: 0px;\n          }\n          @media (min-width: 768px) {\n            .h-hello-bar p {\n              font-size: 14px;\n            }\n          }\n        \x3c/style\x3e',
         document.head.insertAdjacentHTML("beforeend",a));a='\x3cdiv class\x3d"h-hello-bar"\x3e\n      \x3cp\x3e\n        Paket de\u011fi\u015fiminde cayma \u00fccreti yans\u0131maz. Paket haklar\u0131n\u0131 ve i\u00e7eriklerini kullanmaya paket\n        de\u011fi\u015fiminden sonra gelen SMS\u2019in ard\u0131ndan hemen ba\u015flayabilirsiniz.\n      \x3c/p\x3e\n    \x3c/div\x3e';var c=document.querySelector(hype.isMobile()?"h1.title":"#main_container");c.insertAdjacentHTML(hype.isMobile()?"beforebegin":
         "afterbegin",a)}))}})();
      </script><script type="text/javascript" id="">hype.isMobile()?hype.checkifloaded("document.querySelectorAll('#product-list-cards').length \x3e 0",function(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"hypeCategoryCountdownEvent"})}):hype.checkifloaded("document.querySelectorAll('h1.product-list__title').length \x3e 0",function(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"hypeCategoryCountdownEvent"})});</script><script type="text/javascript" id="">(function(){function a(c){0>c.clientY&&(window.dataLayer=window.dataLayer||[],window.dataLayer.push({event:"hypeExitIntentPopupEvent"}),document.removeEventListener("mouseleave",a))}var b=1E3;/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)?setTimeout(function(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"hypeExitIntentPopupEvent"})},10*b):setTimeout(function(){document.addEventListener("mouseleave",a)},3*b)})();</script><script type="text/javascript" id="">if("/kampanyalar/ev-interneti-fiber-kampanyalari/1000-mbps-fiber-firsat-kampanyasi"==location.pathname){var button=document.querySelector("a.but.but--primary.has-hover-icon.text-satura.text-truncate.marv")||document.querySelector(".btn.button-cta.satinal-btn");button.addEventListener("click",function(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"GAEvent",eventCategory:"AB Test",eventAction:"Dijitale \u00d6zel Ba\u015fvur Buton Click",eventLabel:location.pathname})})}else"/kampanyalar/form/1000-mbps-fiber-firsat-kampanyasi"==
         location.pathname&&(button=document.querySelector("#sol-campaign-form-submit-button"),button.addEventListener("click",function(){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:"GAEvent",eventCategory:"AB Test",eventAction:"Dijitale \u00d6zel Ba\u015fvur Buton Click",eventLabel:location.pathname})}));
      </script><script type="text/javascript" id="">localStorage.getItem("16_20_OCAK_BU_MU_BU_MU")||(window.dataLayer=window.dataLayer||[],window.dataLayer.push({event:"START_16_20_OCAK_BU_MU_BU_MU"}));</script><script type="text/javascript" id="">1==window.hasOwnProperty("utag_data")&&("undefined"!=typeof utag_data["js_page.cust.customer_id"]&&dataLayer.push({customerId:utag_data["js_page.cust.customer_id"],customerDevice:utag_data["js_page.cust.Cus_device_brand"]+" | "+utag_data["js_page.cust.Cus_device_model"],customerPackage:utag_data["js_page.cust.customer_package"],customerPaymentType:utag_data["js_page.cust.payment_type"],customerSkStatus:utag_data["js_page.cust.customer_sk_status"],customerSegment:utag_data["js_page.cust.customer_segment_ALTS"]}),
         dataLayer.push({event:"crmLoaded"}));
      </script><script type="text/javascript" id="">!function(d,e,f,g,h,k,a,b,c){d[g]||(a=d[g]=function(){"function"===typeof a.execute?a.execute.apply(a,arguments):a.queue.push(arguments)},a.version="1.0",a.queue=[],b=e.createElement(f),b.async=!0,a.svc=h,b.src=h+k,c=e.getElementsByTagName(f)[0],c.parentNode.insertBefore(b,c))}(window,document,"script","advermind","https://signals.turkcell.com.tr","/base.js");advermind("init","470016443928963");advermind("track","PageView");</script>
      <script type="text/javascript" id="">$(document).ready(function(){$("section a,section .a-btn-icon,section button,section canvas").click(function(a){var e=$(this);a=["m-slider_prev","m-slider_next","m-card--product"];var f=!0;$.each(a,function(k,g){e.hasClass(g)&&(f=!1)});if(1==f){var d=$(this).closest("section"),b=$(this).closest(".m-carousel div[id*\x3d'banner-']");a=null;0!==d.length&&(a=d);0!==b.length&&(a=b);if(0!==a.length&&void 0!==a.attr("data-ga-id")){d=a.attr("data-ga-id");b=a.attr("data-ga-name");var c=a.attr("data-ga-creative"),
         h=a.attr("data-ga-position");a=a.attr("data-ga-event-label");void 0!==$(this).attr("data-desc")?a=a+" - "+$(this).attr("data-desc"):void 0!==$(this).attr("title")?a=a+" - "+$(this).attr("title"):void 0!==$(this).attr("href")&&(a=a+" - "+$(this).attr("href"));if("component-passage_stories"==b||"component-passage_campaign_list"==b||"component-passage_opportunity_list"==b)c=e.find("img").attr("src").split("/"),c=c[c.length-1],c=c.split(".")[0];dataLayer=dataLayer||[];dataLayer.push({event:"ecInternalPromotionClick",
         eventCategory:"Internal Promotions",eventAction:"Promotion Click",eventLabel:a,ecommerce:{promoClick:{promotions:[{id:d,name:b,creative:c,position:h}]}}})}}})});
      </script><script type="text/javascript" id="">$(document).ready(function(){window.ga_promo_view_array=[];window.ga_swiper_view_array=[];hype=hype||{};"/"==location.pathname&&hype.checkifloaded("document.querySelector('main .swiper-container') !\x3d\x3d null",function(){var e=document.querySelector("main .swiper-container").swiper,l=e.slides.length-2,f=0,h=function(a){g($(".m-carousel .swiper-slide-next"))},g=function(a){if(void 0!==a.attr("data-ga-id")){var d=null,c=null,b=null,k=null;void 0!==a.attr("data-ga-id")&&(d=a.attr("data-ga-id"));void 0!==
         a.attr("data-ga-name")&&(c=a.attr("data-ga-name"));if("component-passage_stories"==c||"component-passage_campaign_list"==c||"component-passage_opportunity_list"==c)b=t.find("img").attr("src").split("/"),b=b[b.length-1],b=b.split(".")[0];void 0!==a.attr("data-ga-creative")&&(b=a.attr("data-ga-creative"));void 0!==a.attr("data-ga-position")&&(k=a.attr("data-ga-position"));-1==ga_swiper_view_array.indexOf(d)?(dataLayer=dataLayer||[],dataLayer.push({event:"ecInternalPromotionView",eventCategory:"Internal Promotions",
         eventAction:"Promotion View",eventLabel:"",ecommerce:{promoView:{promotions:[{id:d,name:c,creative:b,position:k}]}}}),ga_swiper_view_array.push(d)):(f++,f==l&&e.off("slideChange",h))}};g($(".m-carousel .swiper-slide-active"));e.on("slideChange",h)})});
      </script><script type="text/javascript" id="">0!==document.querySelectorAll(".m-dashboard__phone").length&&document.querySelector(".m-dashboard__phone").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".media__body").length&&document.querySelector(".media__body").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".otp-msisdn").length&&document.querySelector(".otp-msisdn").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#avatar-thumb-holder .member").length&&document.querySelector("#avatar-thumb-holder .member").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".m-user-profile img").length&&document.querySelector(".m-user-profile img").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#profilePicLink .media__image").length&&document.querySelector("#profilePicLink .media__image").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#user_profile_photo .media__body-wrap h3").length&&document.querySelector("#user_profile_photo .media__body-wrap h3").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#header-mobile-search h2").length&&document.querySelector("#header-mobile-search h2").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .nameSurname").length&&document.querySelector("#general-six .nameSurname").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#general-six .msisdn").length&&document.querySelector("#general-six .msisdn").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .address").length&&document.querySelector("#general-six .address").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .addressBilling").length&&document.querySelector("#general-six .addressBilling").setAttribute("data-hj-suppress","");
      </script><script type="text/javascript" id="">0!==document.querySelectorAll(".m-dashboard__phone").length&&document.querySelector(".m-dashboard__phone").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".media__body").length&&document.querySelector(".media__body").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".otp-msisdn").length&&document.querySelector(".otp-msisdn").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#avatar-thumb-holder .member").length&&document.querySelector("#avatar-thumb-holder .member").setAttribute("data-hj-suppress","");0!==document.querySelectorAll(".m-user-profile img").length&&document.querySelector(".m-user-profile img").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#profilePicLink .media__image").length&&document.querySelector("#profilePicLink .media__image").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#user_profile_photo .media__body-wrap h3").length&&document.querySelector("#user_profile_photo .media__body-wrap h3").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#header-mobile-search h2").length&&document.querySelector("#header-mobile-search h2").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .nameSurname").length&&document.querySelector("#general-six .nameSurname").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll("#general-six .msisdn").length&&document.querySelector("#general-six .msisdn").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .address").length&&document.querySelector("#general-six .address").setAttribute("data-hj-suppress","");0!==document.querySelectorAll("#general-six .addressBilling").length&&document.querySelector("#general-six .addressBilling").setAttribute("data-hj-suppress","");
         0!==document.querySelectorAll(".disabledTextbox").length&&document.querySelector(".disabledTextbox").setAttribute("data-hj-suppress","");
      </script>
      <script type="text/javascript" id="" src="https://www.googletagmanager.com/gtag/js?id=DC-10138642"></script><script type="text/javascript" id="">var prElement=document.querySelector('meta[name\x3d"mainCategory"]'),cx_category=prElement&&prElement.getAttribute("content");!function(b,c,d,a){b.mpfContainr||(b.mpfContainr=function(){d.push(arguments)},mpfContainr.q=d,(a=c.createElement("script")).type="application/javascript",a.async=!0,a.src="//cdn.mookie1.com/containr.js",c.head.appendChild(a))}(window,document,[]);
         mpfContainr("V2_872264",{host:"tr-gmtdmp.mookie1.com",tagType:"activity","src.rand":utag_data.timestamp,"src.category-name":cx_category,"src.sales-order-id":utag_data.order_id,"src.basket":utag_data.basket,"src.price":utag_data.tiklaalrev||utag_data.order_total,"src.product-name":utag_data.gsm_product_name||utag_data.product_name,"src.home-page":utag_data.homepage,"src.product-id":utag_data.product_id,"src.sales":utag_data.sales});
      </script>
      <noscript>
         <iframe src="//tr-gmtdmp.mookie1.com/t/v2?tagid=V2_872264&amp;isNoScript&amp;src.category-name=[REPLACE THIS WITH YOUR MACRO AND PASS IN Category]&amp;src.sales-order-id=[REPLACE THIS WITH YOUR MACRO AND PASS IN Sales ID / Order ID]&amp;src.basket=[REPLACE THIS WITH YOUR MACRO AND PASS IN Basket]&amp;src.price=[REPLACE THIS WITH YOUR MACRO AND PASS IN Price]&amp;src.product-name=[REPLACE THIS WITH YOUR MACRO AND PASS IN Product Name]&amp;src.home-page=[REPLACE THIS WITH YOUR MACRO AND PASS IN Home Page]&amp;src.product-id=[REPLACE THIS WITH YOUR MACRO AND PASS IN Product ID]&amp;src.sales=[REPLACE THIS WITH YOUR MACRO AND PASS IN Sales]&amp;src.rand=[timestamp]" height="0" width="0" style="display:none;visibility:hidden"></iframe>
      </noscript>
      <script type="text/javascript" id="">var now=new Date,eventTime=now.getDay()+"/"+Number(now.getMonth()+1)+"/"+now.getFullYear()+"-"+now.getHours()+":"+now.getMinutes()+":"+now.getSeconds();utag_data.timestamp=eventTime;</script><script type="text/javascript" id="" src="//turkcell.api.useinsider.com/ins.js?id=10000432"></script>
      <script type="text/javascript" id="" src="https://www.googletagmanager.com/gtag/js?id=DC-10978247"></script>
      <script type="text/javascript" id="" src="https://www.googletagmanager.com/gtag/js?id=DC-11603480"></script>
      <script type="text/javascript" id="" src="https://www.googletagmanager.com/gtag/js?id=DC-10978658"></script><script type="text/javascript" id="">var hjtags=[],replaceValues=function(b){viki=b;switch(b){case "logged_in":viki="Logged-In";break;case "not_logged_in":viki="Not Logged-In"}return viki},dynhjtag=function(b,a){""!==a&&"undefined"!==a&&"null"!==a&&(a=replaceValues(a),hjtags.push(b+": "+a))};dynhjtag("Customer Type","undefined");dynhjtag("Login Status","undefined");dynhjtag("Package","undefined");dynhjtag("Tariff","undefined");window.hj=window.hj||function(){(window.hj.q=window.hj.q||[]).push(arguments)};
         window.hj("tagRecording",hjtags);
      </script>
      <script type="text/javascript" id="">window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag("js",new Date);gtag("config","DC-10138642");</script>
      <iframe height="0" width="0" style="display: none; visibility: hidden;" src="https://10138642.fls.doubleclick.net/activityi;src=10138642;type=invmedia;cat=turkc0;ord=6251822785696;gtm=2od2n0;auiddc=952129103.1645804765;u1=null;u2=undefined;u3=undefined;u4=undefined;u5=undefined;u6=undefined;u7=undefined;u8=undefined;~oref=http%3A%2F%2Flocalhost%2Fturkcellhattasima%2F?"></iframe><script type="text/javascript" id="">var prElement=document.querySelector('meta[name\x3d"mainCategory"]'),cx_category=prElement&&prElement.getAttribute("content");gtag("event","conversion",{allow_custom_scripts:!0,u1:cx_category,u2:utag_data.order_id,u3:utag_data.basket,u4:utag_data.tiklaalrev||utag_data.order_total,u5:utag_data.gsm_product_name||utag_data.product_name,u6:utag_data.homepage,u7:utag_data.product_id,u8:utag_data.sales,send_to:"DC-10138642/invmedia/turkc0+standard"});</script>
      <noscript>
         <img src="https://ad.doubleclick.net/ddm/activity/src=10138642;type=invmedia;cat=turkc0;u1=[CATEGORY-NAME];u2=[SALES ID / ORDER ID];u3=[BASKET];u4=[PRICE];u5=[PRODUCT-NAME];u6=[HOME-PAGE];u7=[PRODUCT-ID];u8=[SALES];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;tfua=;npa=;ord=1?" width="1" height="1" alt="">
      </noscript>
      <script type="text/javascript" id="">window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag("js",new Date);gtag("config","DC-10978247");</script>
      <iframe height="0" width="0" style="display: none; visibility: hidden;" src="https://10978247.fls.doubleclick.net/activityi;src=10978247;type=turkc0;cat=turkc0;ord=6627070796263;gtm=2od2n0;auiddc=952129103.1645804765;~oref=http%3A%2F%2Flocalhost%2Fturkcellhattasima%2F?"></iframe><script type="text/javascript" id="">gtag("event","conversion",{allow_custom_scripts:!0,send_to:"DC-10978247/turkc0/turkc0+standard"});</script>
      <noscript>
         <img src="https://ad.doubleclick.net/ddm/activity/src=10978247;type=turkc0;cat=turkc0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;tfua=;npa=;gdpr=${GDPR};gdpr_consent=${GDPR_CONSENT_755};ord=1?" width="1" height="1" alt="">
      </noscript>
      <script type="text/javascript" id="">window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag("js",new Date);gtag("config","DC-11603480");</script>
      <script type="text/javascript" id="">window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag("js",new Date);gtag("config","DC-10978658");</script>
      <iframe height="0" width="0" style="display: none; visibility: hidden;" src="https://10978658.fls.doubleclick.net/activityi;src=10978658;type=comtr0;cat=turkc0;ord=1121764895461;gtm=2od2n0;auiddc=952129103.1645804765;~oref=http%3A%2F%2Flocalhost%2Fturkcellhattasima%2F?"></iframe><script type="text/javascript" id="">gtag("event","conversion",{allow_custom_scripts:!0,send_to:"DC-10978658/comtr0/turkc0+standard"});</script>
      <noscript>
         <img src="https://ad.doubleclick.net/ddm/activity/src=10978658;type=comtr0;cat=turkc0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;tfua=;npa=;gdpr=${GDPR};gdpr_consent=${GDPR_CONSENT_755};ord=1?" width="1" height="1" alt="">
      </noscript>
      <iframe id="insider-worker" src="https://turkcell.api.useinsider.com/worker-new.html" style="display: none;"></iframe>
   </body>
</html>